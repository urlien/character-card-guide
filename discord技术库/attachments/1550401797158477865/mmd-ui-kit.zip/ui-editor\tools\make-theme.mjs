// 一次性把 -1 全局美化改造成「变量 + 兜底」结构：
//   硬编码色 → var(--uix-xxx, 原值)，默认产物视觉与原来完全一致；
//   变量声明块由 config.data.theme 注入，改主题只改配置。
// 用法：node tools/make-theme.mjs
import fs from 'fs';
import path from 'path';
import { ROOT, readJson, writeJson, writeText } from './lib.mjs';

// 只挑出现 >=3 次的主色；出现 1 次的孤立色参数化收益低，不动
export const THEME_VARS = [
  ['text', '#eaf2ff', '主文字'],
  ['text-dim', '#9fb2d3', '次要文字'],
  ['bg-deep', '#101b33', '最深底色'],
  ['accent', '#6fd4ff', '强调色（冷银蓝）'],
  ['panel', '#12203c', '面板底'],
  ['text-bright', '#eef5ff', '高亮文字'],
  ['muted', '#5f7199', '弱化文字'],
  ['panel-2', '#16294a', '面板底（浅一档）'],
  ['bg', '#0d1830', '通用底色'],
  ['panel-3', '#13203f', '面板底（另一档）'],
];

// 优先读模板文件（extract 落盘的 -1 原文或改造版）；没有模板时才退回 base
const tplPath = path.join(ROOT, 'src/template/-1.txt');
let css = fs.existsSync(tplPath) ? fs.readFileSync(tplPath, 'utf8') : null;
if (css == null) {
  const base = readJson(path.join(ROOT, 'src/base.json'));
  const s = base.regex_scripts.find(x => x.id === -1);
  if (!s) throw new Error('找不到规则 -1：先跑 node uix.mjs init <源包>');
  css = s.replaceString;
}
// 幂等：模板已改造过就不再改，否则会把占位符替换成占位符里的东西
if (css.indexOf('__INJECT__theme__') >= 0) {
  console.log('== 主题槽已存在，跳过 ==');
  process.exit(0);
}
const before = css.length;
const stats = [];
for (const [k, hex] of THEME_VARS) {
  const re = new RegExp(hex.replace(/[-]/g, '\\-'), 'gi');
  const n = (css.match(re) || []).length;
  css = css.replace(re, 'var(--uix-' + k + ', ' + hex + ')');
  stats.push([k, hex, n]);
}

// 变量声明块插到第一个 <style> 之后
const st = css.indexOf('<style>');
if (st < 0) throw new Error('-1 里找不到 <style>');
css = css.slice(0, st + 7) + '\n__INJECT__theme__' + css.slice(st + 7);

writeText(path.join(ROOT, 'src/template/-1.txt'), css);
writeJson(path.join(ROOT, 'src/theme.default.json'), {
  _note: '改这里就能换主题。vars 是变量值，extra 是追加的自定义 CSS。',
  vars: Object.fromEntries(THEME_VARS.map(([k, v]) => ['--uix-' + k, v])),
  extra: '',
});

console.log('== 主题槽生成 ==');
stats.forEach(([k, hex, n]) => console.log('   --uix-' + k.padEnd(12), hex.padEnd(9), n + ' 处'));
console.log('   合计替换', stats.reduce((a, x) => a + x[2], 0), '处');
console.log('   模板: src/template/-1.txt（+', css.length - before, '字）');
console.log('   默认值: src/theme.default.json');
