// 共用工具：括号匹配取字面量、字面量求值、路径读写
import fs from 'fs';
import path from 'path';
import vm from 'vm';

export const ROOT = path.resolve(path.dirname(new URL(import.meta.url).href.replace(/^file:\/\//, '').replace(/^\/([A-Za-z]:)/, '$1')), '..');

export function readJson(p) { return JSON.parse(fs.readFileSync(p, 'utf8')); }
export function writeJson(p, v) { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, JSON.stringify(v, null, 2), 'utf8'); }
export function writeText(p, v) { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, v, 'utf8'); }

// 从 openIdx（指向 [ 或 {）开始做括号匹配，跳过字符串与注释，返回闭合字符下标
export function matchBracket(text, openIdx) {
  const open = text[openIdx];
  const close = open === '[' ? ']' : '}';
  let depth = 0, i = openIdx;
  while (i < text.length) {
    const c = text[i];
    if (c === '"' || c === "'" || c === '`') {
      const q = c; i++;
      while (i < text.length) {
        if (text[i] === '\\') { i += 2; continue; }
        if (text[i] === q) break;
        i++;
      }
      i++; continue;
    }
    if (c === '/' && text[i + 1] === '/') { while (i < text.length && text[i] !== '\n') i++; continue; }
    if (c === '/' && text[i + 1] === '*') { i += 2; while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++; i += 2; continue; }
    if (c === open) depth++;
    else if (c === close) { depth--; if (depth === 0) return i; }
    i++;
  }
  return -1;
}

// 剥掉注释（跳过字符串内的内容）。清洗模板注释后，骨架比对要忽略注释差异。
// 只认 " 和 ' ：这些脚本里反引号大量出现在注释和正则中，把它当模板字符串会漏剥注释。
export function stripComments(text) {
  let out = '', i = 0;
  while (i < text.length) {
    const c = text[i];
    if (c === '"' || c === "'") {
      const q = c; out += c; i++;
      while (i < text.length) {
        if (text[i] === '\\') { out += text.slice(i, i + 2); i += 2; continue; }
        out += text[i];
        if (text[i] === q) { i++; break; }
        i++;
      }
      continue;
    }
    if (c === '/' && text[i + 1] === '/') { while (i < text.length && text[i] !== '\n') i++; continue; }
    if (c === '/' && text[i + 1] === '*') { i += 2; while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++; i += 2; continue; }
    out += c; i++;
  }
  return out;
}

// 把 JS 字面量原文求值为真实对象
export function evalLiteral(src) {
  return vm.runInNewContext('(' + src + ')', Object.create(null), { timeout: 5000 });
}

// 把值序列化成可安全内嵌进 <script> 的 JS 字面量。
// 用紧凑格式：产物是给机器读的，而多条规则已逼近 20000 字上限，缩进纯属浪费。
export function toLiteral(value) {
  return JSON.stringify(value)
    .replace(/<\/script/gi, '<\\/script')
    .replace(/<!--/g, '<\\!--');
}

// 点路径读写
export function getPath(obj, p) {
  return p.split('.').reduce((o, k) => (o == null ? o : o[k]), obj);
}
export function setPath(obj, p, v) {
  const ks = p.split('.');
  let o = obj;
  for (let i = 0; i < ks.length - 1; i++) {
    if (o[ks[i]] == null) o[ks[i]] = {};
    o = o[ks[i]];
  }
  o[ks[ks.length - 1]] = v;
  return obj;
}

export function findScript(pack, id) {
  const s = pack.regex_scripts.find(x => x.id === id);
  if (!s) throw new Error('未找到规则 id=' + id);
  return s;
}
