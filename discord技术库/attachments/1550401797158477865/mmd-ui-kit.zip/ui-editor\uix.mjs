#!/usr/bin/env node
// mmd-ui-kit 命令行入口。所有子命令都只是转发到 tools/ 下的脚本，方便 agent 与人统一调用。
//
//   node uix.mjs init    <源包.json> [配置名]    从一张卡抽出模板 + 配置（第一次用必跑）
//   node uix.mjs build   [配置名] [输出名]       配置 + 模板 → 可导入的正则包
//   node uix.mjs verify  [源包.json] [产物.json] 回读闭环自检（产物是否等价于源包）
//   node uix.mjs example                         生成中性示例配置并打包
//   node uix.mjs theme                           重新生成主题变量槽（只在改过 -1 模板后需要）
//   node uix.mjs list                            列出所有可配置字段
//   node uix.mjs check   <产物.json>             用技能自带校验器体检（需要传入技能目录）
//
// 退出码：0 = 通过；非 0 = 有错误（体积超限 / 校验失败 / 参数不对）
import { spawnSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { ROOT, readJson } from './tools/lib.mjs';

const node = process.execPath;
const T = (f) => path.join(ROOT, 'tools', f);

function run(file, args) {
  const r = spawnSync(node, [T(file), ...args], { stdio: 'inherit' });
  if (r.error) { console.error(r.error.message); process.exit(1); }
  return r.status || 0;
}

const HELP = `mmd-ui-kit —— 把一套跑通的 MMD 角色卡 UI 变成「配置 → 打包」的工程

用法：
  node uix.mjs init    <源包.json> [配置名]   从一张卡抽出模板 + 配置（首次必跑）
  node uix.mjs build   [配置名] [输出名]      配置 + 模板 → out/<输出名>.json
  node uix.mjs verify  [源包.json] [产物.json] 回读闭环自检
  node uix.mjs example                        生成中性示例配置并打包
  node uix.mjs theme                          重新生成主题变量槽
  node uix.mjs list                           列出所有可配置字段
  node uix.mjs diff    <配置A> <配置B>        对比两份配置的差异字段

典型流程：
  1. node uix.mjs init  "角色卡【xxxx】正则数据.json" mine
  2. 编辑 config/mine.json
  3. node uix.mjs build mine
  4. 把 out/mine.json 拿到平台「导入正则」
`;

const [cmd, ...rest] = process.argv.slice(2);

switch (cmd) {
  case 'init': {
    // init = extract（生成原始模板）→ theme（改造 -1）→ extract（把主题默认值写进配置）
    if (!rest[0]) {
      console.error('需要一个源包路径：node uix.mjs init <源包.json> [配置名]');
      process.exit(1);
    }
    const srcAbs = path.resolve(rest[0]);
    if (!fs.existsSync(srcAbs)) { console.error('找不到源包：' + srcAbs); process.exit(1); }
    const name = rest[1] || 'current';
    let st = run('extract.mjs', [srcAbs, name]);
    if (st) process.exit(st);
    console.log('\n-- 改造 -1 主题 --');
    st = run('make-theme.mjs', []);
    if (st) process.exit(st);
    console.log('\n-- 回写主题默认值 --');
    st = run('extract.mjs', [srcAbs, name]);
    if (st) process.exit(st);
    console.log('\n初始化完成。接下来：编辑 config/' + name + '.json，然后 node uix.mjs build ' + name);
    break;
  }
  case 'build':
    process.exit(run('build.mjs', rest.slice(0, 2)));
    break;
  case 'verify':
    process.exit(run('verify.mjs', rest.slice(0, 2)));
    break;
  case 'theme':
    process.exit(run('make-theme.mjs', []));
    break;
  case 'example': {
    let st = run('make-example.mjs', []);
    if (st) process.exit(st);
    process.exit(run('build.mjs', ['example']));
    break;
  }
  case 'list': {
    const m = readJson(path.join(ROOT, 'src/manifest.json'));
    console.log('== 数据槽（config.data.*）==');
    for (const s of m.slots) {
      console.log('  ', String(s.id).padStart(4), s.key.padEnd(26), (s.kind || 'data').padEnd(11), s.note || '');
    }
    console.log('\n== 正则槽 ==');
    for (const s of m.regexSlots || []) console.log('  ', String(s.id).padStart(4), s.key.padEnd(26), s.kind, '—', s.note || '');
    console.log('\n== 顶层字段 ==');
    for (const k of m.metaSlots || []) console.log('  ', 'meta.' + k);
    console.log('\n== 模块开关 ==');
    console.log('   data.modules: profile / map / bestiary / status / helper / guide / who');
    break;
  }
  case 'diff': {
    const [a, b] = rest;
    if (!a || !b) { console.error('用法：node uix.mjs diff <配置A> <配置B>'); process.exit(1); }
    const ca = readJson(path.join(ROOT, 'config', a + '.json'));
    const cb = readJson(path.join(ROOT, 'config', b + '.json'));
    const flat = (o, p, out) => {
      for (const k of Object.keys(o || {})) {
        const v = o[k], key = p ? p + '.' + k : k;
        if (v && typeof v === 'object' && !Array.isArray(v)) flat(v, key, out);
        else out[key] = JSON.stringify(v);
      }
      return out;
    };
    const fa = flat(ca.data, '', {}), fb = flat(cb.data, '', {});
    const keys = [...new Set([...Object.keys(fa), ...Object.keys(fb)])].sort();
    let n = 0;
    for (const k of keys) {
      if (fa[k] === fb[k]) continue;
      n++;
      console.log('  ' + k);
      console.log('    ' + a + ': ' + String(fa[k]).slice(0, 120));
      console.log('    ' + b + ': ' + String(fb[k]).slice(0, 120));
    }
    console.log(n ? `\n共 ${n} 处不同` : '两份配置的数据区完全一致');
    break;
  }
  case 'check': {
    // 用技能自带校验器体检产物；技能目录可环境变量覆盖
    const skill = process.env.UIX_SKILL_DIR || 'C:/Users/Gilgamesh/.workbuddy/skills/generating-role-card';
    const v = path.join(skill, 'scripts/validate.mjs');
    if (!fs.existsSync(v)) { console.error('找不到校验器：' + v + '（用 UIX_SKILL_DIR 指定技能目录）'); process.exit(1); }
    const r = spawnSync(node, [v, path.resolve(rest[0] || path.join(ROOT, 'out/current.json'))], { stdio: 'inherit' });
    process.exit(r.status || 0);
    break;
  }
  case 'help':
  case '--help':
  case '-h':
  case undefined:
    console.log(HELP);
    break;
  default:
    console.error('未知子命令：' + cmd + '\n');
    console.error(HELP);
    process.exit(1);
}
