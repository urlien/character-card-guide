// 统计一条规则里的颜色出现频次，用于挑选主题变量槽
import fs from 'fs';
import path from 'path';
import { ROOT, readJson } from './lib.mjs';

const id = Number(process.argv[2] || -1);
const tplPath = path.join(ROOT, 'src/template', id + '.txt');
let text;
if (fs.existsSync(tplPath)) text = fs.readFileSync(tplPath, 'utf8');
else {
  const base = readJson(path.join(ROOT, 'src/base.json'));
  const s = base.regex_scripts.find(x => x.id === id);
  if (!s) throw new Error('既无模板也无 base 规则：' + id);
  text = s.replaceString;
}
const map = new Map();
const add = (m) => { const k = m[0].toLowerCase(); map.set(k, (map.get(k) || 0) + 1); };
for (const m of text.matchAll(/#[0-9a-fA-F]{3,8}\b/g)) add(m);
for (const m of text.matchAll(/rgba?\([^)]*\)/g)) add(m);

const rows = [...map.entries()].sort((a, b) => b[1] - a[1]);
console.log('共', rows.length, '种颜色，出现总数', rows.reduce((a, r) => a + r[1], 0));
console.log('\n频次 >= 2 的：');
rows.filter(r => r[1] >= 2).forEach(([c, n]) => console.log('  ', String(n).padStart(3), c));
console.log('\n其余（1 次）：', rows.filter(r => r[1] === 1).length, '种');
