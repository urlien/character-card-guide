// 回读闭环校验：产物包 vs 源包
//   A. 骨架等价：两边都把数据区挖掉后，剩余文本必须逐字节相同（证明模板抽取无损）
//   B. 数据等价：从产物里重新求值出的数据，必须等于配置里的数据
// 用法：node tools/verify.mjs <源包.json> [产物.json]
import fs from 'fs';
import path from 'path';
import { ROOT, readJson, matchBracket, evalLiteral, getPath, stripComments } from './lib.mjs';

const srcPath = process.argv[2] || 'C:/Users/Gilgamesh/Pictures/白月光/角色卡【319600】正则数据_凉月夜景_新图鉴.json';
const outPath = process.argv[3] || path.join(ROOT, 'out/current.json');
const manifest = readJson(path.join(ROOT, 'src/manifest.json'));
const src = readJson(srcPath);
const out = readJson(outPath);
const config = readJson(path.join(ROOT, 'config/current.json'));

let pass = 0, fail = 0;
const ok = (m) => { pass++; console.log('   [OK] ' + m); };
const bad = (m) => { fail++; console.log('   [!!] ' + m); };

// 模板生成时会对源文本套一遍 sanitize（清掉注释里的示例人名等）。
// 比对前源包侧也套一遍，剩下的差异才是真的差异。
const sanPath = path.join(ROOT, 'src/sanitize.json');
const san = fs.existsSync(sanPath) ? readJson(sanPath) : { rules: [] };
function presanitize(t) {
  for (const r of san.rules || []) t = t.split(r.find).join(r.replace);
  return t;
}

// 把一条规则里所有数据区挖成同一占位符
function skeleton(text, id) {
  for (const slot of manifest.slots) {
    if (slot.id !== id) continue;
    if (slot.kind === 'between') {
      const si = text.indexOf(slot.start);
      if (si < 0) continue;
      const ei = text.indexOf(slot.end, si + slot.start.length);
      if (ei < 0) continue;
      text = text.slice(0, si + slot.start.length) + '#' + slot.key + '#' + text.slice(ei);
      continue;
    }
    if (slot.kind === 'swap') {
      // 先把产物侧已注入的值还原成「源包原文形态」，再判断是否还需要改造：
      // 产物侧改造过了就不必再来一次，否则会插出第二份
      for (const nz of slot.normalize || []) {
        text = text.replace(new RegExp(nz.pattern), (m, g1) => {
          if (nz.replace === '@unquote') { try { return JSON.parse('"' + g1 + '"'); } catch (e) { return m; } }
          return nz.replace;
        });
      }
      if (text.indexOf('__INJECT__' + slot.key + '__') < 0) {
        for (const sw of slot.swaps || []) {
          if (sw.re) {
            const rx = new RegExp(sw.re);
            if (rx.test(text)) text = text.replace(rx, sw.to);
          } else text = text.split(sw.find).join(sw.replace);
        }
      }
      continue;
    }
    if (slot.kind === 'aliasTable') {
      // 源包侧是一串 add('x',[...]);，产物侧是一行回放循环，两边都抹平
      text = text.replace(/var _AL=[\s\S]*?_AL\[_i\]\.words\); \}/, '');
      text = text.replace(/add\('[^']+',\s*\[[^\]]*\]\);/g, '');
      // 源包逐条删除会留下一串只含缩进的空行，产物整块删除不会；两边都压平后再比
      text = text.replace(/(\n[ \t]*)+/g, '\n');
      continue;
    }
    if (slot.kind === 'whole' || !slot.start) continue;
    const i = text.indexOf(slot.start);
    if (i < 0) continue;
    const openIdx = i + slot.start.length - 1;
    const closeIdx = matchBracket(text, openIdx);
    if (closeIdx < 0) continue;
    text = text.slice(0, openIdx) + '#' + slot.key + '#' + text.slice(closeIdx + 1);
  }
  return text;
}

console.log('== A. 骨架等价（挖掉数据区后逐字节比对）==');
const srcIds = src.regex_scripts.map(s => s.id);
const outIds = out.regex_scripts.map(s => s.id);
if (JSON.stringify(srcIds) !== JSON.stringify(outIds)) bad('规则 id 顺序不一致');
else ok('规则数与顺序一致（' + srcIds.length + ' 条）');

// 主题槽：产物把硬编码色改成了 var(--uix-x, 原值)，并多出一个变量块。
// 把变量块摘掉、变量还原成原值后，必须与源包逐字节相同 —— 这才能证明「默认视觉不变」。
function untheme(text) {
  return text
    .replace(/\[data-chat=root\]\{[^}]*\}\n?/, '')
    .replace(/var\(--uix-[a-z0-9-]+,\s*([^)]+)\)/g, '$1');
}

for (const id of srcIds) {
  const a = src.regex_scripts.find(s => s.id === id);
  const b = out.regex_scripts.find(s => s.id === id);
  if (a.scriptName !== b.scriptName) { bad(id + ' 名称不一致'); continue; }

  const kinds = new Set(manifest.slots.filter(s => s.id === id).map(s => s.kind));
  if (kinds.has('theme')) {
    if (untheme(b.replaceString) === presanitize(a.replaceString)) ok(`${id} ${a.scriptName}：变量还原后与源包逐字节相同（默认视觉不变）`);
    else bad(`${id} ${a.scriptName}：主题改造后与源包不一致`);
    if (/\[data-chat=root\]\{--uix-/.test(b.replaceString)) ok(`${id} 变量块已注入 [data-chat=root]`);
    else bad(`${id} 变量块未注入`);
    continue;
  }
  if (kinds.has('hud')) {
    if (b.replaceString === a.replaceString) ok(`${id} ${a.scriptName}：结构化重建后与源包逐字节相同`);
    else {
      bad(`${id} ${a.scriptName}：重建结果与源包不同`);
      console.log('        源: ' + a.replaceString);
      console.log('        产: ' + b.replaceString);
    }
    continue;
  }

  // 注释不影响行为，比对前剥掉（模板里的示例性注释会被 sanitize 清洗）
  const sa = stripComments(skeleton(presanitize(a.replaceString), id));
  const sb = stripComments(skeleton(presanitize(b.replaceString), id));
  if (sa === sb) ok(`${id} ${a.scriptName}：骨架逐字节相同（${sa.length} 字，已忽略注释）`);
  else {
    // 定位首个差异
    let i = 0; while (i < sa.length && sa[i] === sb[i]) i++;
    bad(`${id} ${a.scriptName}：骨架在 ${i} 处不同`);
    console.log('        源: …' + JSON.stringify(sa.slice(Math.max(0, i - 40), i + 40)));
    console.log('        产: …' + JSON.stringify(sb.slice(Math.max(0, i - 40), i + 40)));
  }
  if (a.findRegex !== b.findRegex) {
    if (id === -12) console.log('        （-12 为预期差异：事件词表已按面板补全）');
    else bad(`${id} findRegex 不一致`);
  }
}

console.log('\n== B. 数据等价（产物里重新求值 == 配置）==');
for (const slot of manifest.slots) {
  const s = out.regex_scripts.find(x => x.id === slot.id);
  const expected = getPath(config, 'data.' + slot.key);
  let actual;
  if (slot.kind === 'theme') {
    const m = s.replaceString.match(/\[data-chat=root\]\{([^}]*)\}/);
    actual = { vars: Object.fromEntries((m ? m[1] : '').split(';').filter(Boolean).map(x => x.split(':'))) };
    const e = { vars: expected.vars || {} };
    if (JSON.stringify(actual) === JSON.stringify(e)) ok('theme 变量块一致（' + Object.keys(actual.vars).length + ' 个变量）');
    else bad('theme 变量块不一致');
    continue;
  }
  if (slot.kind === 'hud') {
    if (slot.key === 'hud.title') {
      actual = (s.replaceString.match(/class="bs-title">([^<]*)</) || [])[1];
    } else {
      actual = [...s.replaceString.matchAll(/<button[^>]*onclick="([^"]+)"[^>]*>([^<]*)</g)]
        .map(m => ({ label: m[2], fn: m[1].replace(/\(\)$/, ''), module: (manifest.hudFnModule || {})[m[1].replace(/\(\)$/, '')] || '' }));
    }
    if (JSON.stringify(actual) === JSON.stringify(expected)) ok(slot.key + ' 一致');
    else bad(slot.key + ' 不一致：' + JSON.stringify(actual) + ' vs ' + JSON.stringify(expected));
    continue;
  }
  if (slot.kind === 'between') {
    const i = s.replaceString.indexOf(slot.start);
    const j = s.replaceString.indexOf(slot.end, i + slot.start.length);
    actual = s.replaceString.slice(i + slot.start.length, j);
    if (actual === expected) ok(slot.key + ' 一致（' + actual + '）');
    else bad(slot.key + ' 不一致：' + JSON.stringify(actual) + ' vs ' + JSON.stringify(expected));
    continue;
  }
  if (slot.kind === 'aliasTable') {
    const i = s.replaceString.indexOf('var _AL=');
    const openIdx = i + 'var _AL='.length;
    const closeIdx = matchBracket(s.replaceString, openIdx);
    actual = evalLiteral(s.replaceString.slice(openIdx, closeIdx + 1));
    if (JSON.stringify(actual) === JSON.stringify(expected)) ok(slot.key + ' 一致（' + actual.length + ' 条别名）');
    else bad(slot.key + ' 不一致');
    continue;
  }
  if (slot.kind === 'swap') {
    if (slot.extractFrom) {
      // 文案型：从产物里按同一组正则重新抽一遍
      actual = {};
      for (const f of slot.extractFrom) {
        const mm = s.replaceString.match(new RegExp(f.re));
        // 注入后形如 '+"文案"+'，剥掉拼接符与引号才是配置里的值
        let v = mm ? mm[1] : null;
        const q = v && v.match(/^'\+("(?:[^"\\]|\\.)*")\+'$/);
        actual[f.field] = q ? JSON.parse(q[1]) : v;
      }
    } else {
      const m = s.replaceString.match(/var BARF=([^;]*);/);
      actual = m ? evalLiteral(m[1]) : null;
    }
    if (JSON.stringify(actual) === JSON.stringify(expected)) ok(slot.key + ' 一致（' + JSON.stringify(actual) + '）');
    else bad(slot.key + ' 不一致：' + JSON.stringify(actual) + ' vs ' + JSON.stringify(expected));
    continue;
  }
  if (slot.kind === 'whole') actual = s.replaceString;
  else {
    const i = s.replaceString.indexOf(slot.start);
    const openIdx = i + slot.start.length - 1;
    const closeIdx = matchBracket(s.replaceString, openIdx);
    actual = evalLiteral(s.replaceString.slice(openIdx, closeIdx + 1));
  }
  const same = JSON.stringify(actual) === JSON.stringify(expected);
  if (same) ok(slot.key + ' 一致');
  else bad(slot.key + ' 不一致');
}

console.log('\n== C. 顶层字段 ==');
for (const k of ['pageDepth', 'chatVersion', 'statusbar']) {
  if (String(src[k]) === String(out[k])) ok(`${k} = ${JSON.stringify(out[k])}`);
  else bad(`${k}: 源 ${JSON.stringify(src[k])} vs 产 ${JSON.stringify(out[k])}`);
}
if (src.beginning === out.beginning) ok('beginning 一致（' + out.beginning.length + ' 字）');
else bad('beginning 不一致');

console.log(`\n结果：${pass} 通过 / ${fail} 失败`);
process.exitCode = fail ? 1 : 0;
