// 从一张现成的卡（正则包）里抽出「模板 + 配置」：
//   1. 把各模块的数据区替换成占位符，存为 src/template/<id>.txt
//   2. 把数据本身求值后存为 config/<name>.json
//   3. 其余部分原样存为 src/base.json（被抽走的地方留 __TPL__ / __REGEX__ / __META__ 标记）
// 用法：node tools/extract.mjs <源包.json> <输出配置名>
import fs from 'fs';
import path from 'path';
import { ROOT, readJson, writeJson, writeText, matchBracket, evalLiteral, getPath, setPath, findScript } from './lib.mjs';

const srcPath = process.argv[2] || 'C:/Users/Gilgamesh/Pictures/白月光/角色卡【319600】正则数据_凉月夜景_新图鉴.json';
const name = process.argv[3] || 'current';

const manifest = readJson(path.join(ROOT, 'src/manifest.json'));
const pack = readJson(srcPath);

// base 用深拷贝，避免污染
const base = JSON.parse(JSON.stringify(pack));
const config = { meta: { name: pack.regex_scripts.length + ' rules' }, data: {} };
const report = [];

// 顶层 meta
for (const k of manifest.metaSlots) {
  const v = base[k];
  if (typeof v === 'string') {
    setPath(config, 'meta.' + k, v);
    base[k] = '__META__' + k + '__';
  }
}

// 数据槽
const touched = new Set();
// 同一条规则可能有多个槽：每次都从源包原文起步，再用 workset 传递该规则已被挖走若干段的最新副本，
// 保证「定位与替换在同一份文本上」且重跑 extract 完全幂等
const workset = new Map();
for (const slot of manifest.slots) {
  const s = findScript(pack, slot.id);
  let tpl;
  if (slot.kind === 'theme') tpl = getTemplate(slot.id) || s.replaceString;
  else if (workset.has(slot.id)) tpl = workset.get(slot.id);
  else tpl = s.replaceString;
  let value;

  if (slot.kind === 'theme') {
    // 主题槽的模板由 make-theme.mjs 改造。首次运行时模板还是源包原文，
    // 先落盘让 make-theme 有东西可改，改造完再跑一次 extract 就会取到默认值。
    if (tpl.indexOf('__INJECT__theme__') < 0) {
      saveTemplate(slot.id, tpl); touched.add(slot.id);
      report.push({ key: slot.key, id: slot.id, size: '待 make-theme 改造' });
      continue;
    }
    value = readJson(path.join(ROOT, 'src/theme.default.json'));
    setPath(config, 'data.' + slot.key, value);
    saveTemplate(slot.id, tpl); touched.add(slot.id);
    report.push({ key: slot.key, id: slot.id, size: JSON.stringify(value).length });
    continue;
  }

  if (slot.kind === 'hud') {
    const html = s.replaceString;
    const titleM = html.match(/class="bs-title">([^<]*)</);
    const btns = [];
    const re = /<button[^>]*onclick="([^"]+)"[^>]*>([^<]*)</g;
    let m;
    while ((m = re.exec(html))) {
      const fn = m[1].replace(/\(\)\s*$/, '');
      btns.push({ label: m[2], fn: fn, module: (manifest.hudFnModule || {})[fn] || '' });
    }
    value = slot.key === 'hud.title' ? (titleM ? titleM[1] : '') : btns;
    if (slot.key === 'hud.title') {
      tpl = '<div class="bs-hud"><span class="bs-title">__INJECT__hud.title__</span>'
        + '<span class="bs-actions">__INJECT__hud.buttons__</span></div>';
    }
    setPath(config, 'data.' + slot.key, value);
    if (slot.key === 'hud.title') saveTemplate(slot.id, tpl);
    touched.add(slot.id);
    report.push({ key: slot.key, id: slot.id, size: JSON.stringify(value).length });
    continue;
  }

  // 夹在两个标记之间的短文本（HTML 里的小字标题之类）
  if (slot.kind === 'between') {
    const si = tpl.indexOf(slot.start);
    if (si < 0) throw new Error(`[${slot.key}] 找不到起始标记: ${slot.start}`);
    const ei = tpl.indexOf(slot.end, si + slot.start.length);
    if (ei < 0) throw new Error(`[${slot.key}] 找不到结束标记: ${slot.end}`);
    value = tpl.slice(si + slot.start.length, ei);
    tpl = tpl.slice(0, si + slot.start.length) + '__INJECT__' + slot.key + '__' + tpl.slice(ei);
    workset.set(slot.id, tpl);
    setPath(config, 'data.' + slot.key, value);
    saveTemplate(slot.id, tpl);
    touched.add(slot.id);
    report.push({ key: slot.key, id: slot.id, size: String(value).length });
    continue;
  }

  // 写死在渲染代码里的字段名 / 文案：按 manifest 声明的片段做替换，值抽进配置
  if (slot.kind === 'swap') {
    // 默认值优先从源包原文抽（extractFrom），抽不到才用 manifest 里的 default
    value = slot.default ? JSON.parse(JSON.stringify(slot.default)) : {};
    if (slot.extractFrom) {
      for (const f of slot.extractFrom) {
        const m = tpl.match(new RegExp(f.re));
        if (m) value[f.field] = m[1];
      }
    }
    for (const sw of slot.swaps || []) {
      if (sw.re) {
        const rx = new RegExp(sw.re);
        // 幂等：若模板已被改造（替换串里的占位符已存在），跳过
        if (/_+INJECT_+/.test(sw.to) && tpl.indexOf(sw.to.match(/__INJECT__[A-Za-z0-9_.]+__/)[0]) >= 0) continue;
        if (!rx.test(tpl)) {
          throw new Error(`[${slot.key}] 模板里匹配不到：${sw.re.slice(0, 60)}…（模板已被改造过？重跑本命令即可从源包重建）`);
        }
        tpl = tpl.replace(rx, sw.to);
      } else {
        if (tpl.indexOf(sw.find) < 0) {
          throw new Error(`[${slot.key}] 模板里找不到待替换片段：${sw.find.slice(0, 50)}…（模板已被改造过？重跑本命令即可从源包重建）`);
        }
        tpl = tpl.split(sw.find).join(sw.replace);
      }
    }
    workset.set(slot.id, tpl);
    setPath(config, 'data.' + slot.key, value);
    saveTemplate(slot.id, tpl);
    touched.add(slot.id);
    report.push({ key: slot.key, id: slot.id, size: Object.keys(value).length + ' 个字段' });
    continue;
  }

  // 字段别名表：一串 add('标准名', [别名...]); 调用，抽成配置后用循环回放
  if (slot.kind === 'aliasTable') {
    const re = /add\('([^']+)',\s*\[([^\]]*)\]\);/g;
    const list = [];
    let mm, first = -1, last = -1;
    while ((mm = re.exec(tpl))) {
      if (first < 0) first = mm.index;
      last = mm.index + mm[0].length;
      list.push({ std: mm[1], words: evalLiteral('[' + mm[2] + ']') });
    }
    if (!list.length) throw new Error(`[${slot.key}] 没找到任何 add(...) 调用`);
    tpl = tpl.slice(0, first)
      + 'var _AL=__INJECT__' + slot.key + '__;for(var _i=0;_i<_AL.length;_i++){ add(_AL[_i].std,_AL[_i].words); }'
      + tpl.slice(last);
    workset.set(slot.id, tpl);
    setPath(config, 'data.' + slot.key, list);
    saveTemplate(slot.id, tpl);
    touched.add(slot.id);
    report.push({ key: slot.key, id: slot.id, size: list.length + ' 条' });
    continue;
  }

  if (slot.kind === 'whole') {
    value = tpl;
    tpl = '__INJECT__' + slot.key + '__';
  } else {
    const startIdx = tpl.indexOf(slot.start);
    if (startIdx < 0) throw new Error(`[${slot.key}] 找不到定位串: ${slot.start}`);
    const openIdx = startIdx + slot.start.length - 1;
    const closeIdx = matchBracket(tpl, openIdx);
    if (closeIdx < 0) throw new Error(`[${slot.key}] 括号匹配失败`);
    value = evalLiteral(tpl.slice(openIdx, closeIdx + 1));
    // 只替换字面量本体，赋值前缀与后面的分号原样保留
    tpl = tpl.slice(0, openIdx) + '__INJECT__' + slot.key + '__' + tpl.slice(closeIdx + 1);
  }

  workset.set(slot.id, tpl);
  setPath(config, 'data.' + slot.key, value);
  saveTemplate(slot.id, tpl);
  touched.add(slot.id);
  report.push({ key: slot.key, id: slot.id, size: JSON.stringify(value).length });
}

function tplFile(id) { return path.join(ROOT, 'src/template', String(id) + '.txt'); }
function getTemplate(id) { const p = tplFile(id); return fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : null; }
function saveTemplate(id, t) { writeText(tplFile(id), t); }

// 正则槽：事件标记
for (const slot of manifest.regexSlots) {
  if (slot.kind !== 'event-marks') continue;
  const s = findScript(pack, slot.id);
  const re = s.findRegex;
  // 形如 <#(?:A|B|C)> 与 【(?:X|Y)】，定位符后面必有 (?:
  const placeM = re.match(/<#\(\?:([^)]*)\)>/);
  const eventM = re.match(/【\(\?:([^)]*)\)】/);
  const places_ = placeM ? placeM[1].split('|') : [];
  const events_ = eventM ? eventM[1].split('|') : [];
  setPath(config, 'data.events.places', places_);
  setPath(config, 'data.events.events', events_);
  base.regex_scripts.find(x => x.id === slot.id).findRegex = '__REGEX__' + slot.key + '__';
  report.push({ key: 'events.places', id: slot.id, size: places_.length });
  report.push({ key: 'events.events', id: slot.id, size: events_.length });
}

// base 里把被参数化的规则替换成模板引用
for (const id of touched) {
  const s = base.regex_scripts.find(x => x.id === id);
  s.replaceString = '__TPL__' + id + '__';
}

// 顺手体检：事件词表与助手面板的 EVT_* 是否一致
const evts = [
  ...(getPath(config, 'data.helper.evt.palace') || []),
  ...(getPath(config, 'data.helper.evt.territory') || []),
  ...(getPath(config, 'data.helper.evt.chaos') || []),
].map(x => String(x).replace(/^【|】$/g, ''));
const inRegex = (getPath(config, 'data.events.events') || []).map(String);
const missing = evts.filter(x => inRegex.indexOf(x) < 0);
const extra = inRegex.filter(x => evts.indexOf(x) < 0);

config.meta.pageDepth = base.pageDepth;
config.meta.chatVersion = base.chatVersion;
config.meta.source = path.basename(srcPath);

// 模块开关：关掉的模块，其按钮不会出现在功能栏
if (!config.data.modules) {
  config.data.modules = {
    _note: 'false = 该组件的功能栏按钮不生成。组件代码仍在包里，想彻底瘦身要自己删规则。',
    profile: true, map: true, bestiary: true, status: true, helper: true, guide: true, who: true
  };
}

// 清理模板里不适合进配置、却会泄露原卡内容的零星文本（多为注释）
const sanPath = path.join(ROOT, 'src/sanitize.json');
let sanCount = 0;
if (fs.existsSync(sanPath)) {
  const san = readJson(sanPath);
  for (const id of touched) {
    const p = tplFile(id);
    let t = fs.readFileSync(p, 'utf8');
    for (const r of san.rules || []) {
      if (t.indexOf(r.find) >= 0) { t = t.split(r.find).join(r.replace); sanCount++; }
    }
    writeText(p, t);
  }
}

writeJson(path.join(ROOT, 'src/base.json'), base);
writeJson(path.join(ROOT, 'config', name + '.json'), config);

console.log('== 抽出数据槽 ==');
report.forEach(r => console.log('  ', String(r.id).padStart(4), r.key.padEnd(24), r.size));
console.log('\n== 事件词表体检 ==');
console.log('   助手面板 EVT_* 合并:', evts.length, '词');
console.log('   -12 正则收录    :', inRegex.length, '词');
console.log('   面板有、正则漏收:', missing.length ? missing.join(' / ') : '（无）');
console.log('   正则有、面板没有:', extra.length ? extra.join(' / ') : '（无）');
if (sanCount) console.log('\n模板清洗:', sanCount, '处');
console.log('\n输出: src/base.json, src/template/*.txt, config/' + name + '.json');
