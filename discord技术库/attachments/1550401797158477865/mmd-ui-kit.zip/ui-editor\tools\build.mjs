// 配置 + 模板 → 可直接「导入正则」的包
// 用法：node tools/build.mjs [配置名] [输出文件名]
//       node tools/build.mjs current           → out/current.json
import fs from 'fs';
import path from 'path';
import { ROOT, readJson, writeJson, toLiteral, getPath, setPath } from './lib.mjs';

const name = process.argv[2] || 'current';
const outName = process.argv[3] || name;
const LIMIT = 20000;

const manifest = readJson(path.join(ROOT, 'src/manifest.json'));
const base = readJson(path.join(ROOT, 'src/base.json'));
const config = readJson(path.join(ROOT, 'config', name + '.json'));

const warns = [];
const errors = [];

const escHtml = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escAttr = (s) => String(s).replace(/[^A-Za-z0-9_$]/g, '');

// 主题：[data-chat=root] 上声明变量（属性选择器一律不加引号），再追加自定义 CSS
function themeCss(v) {
  const vars = (v && v.vars) || {};
  const keys = Object.keys(vars);
  const out = keys.length ? '[data-chat=root]{' + keys.map(k => k + ':' + vars[k]).join(';') + '}' : '';
  return out + ((v && v.extra) ? (out ? '\n' : '') + v.extra : '');
}

// 功能栏按钮：按 data.modules 开关过滤
function buttonsHtml(btns) {
  const mods = getPath(config, 'data.modules') || {};
  const out = [];
  for (const b of btns || []) {
    if (b.module && mods[b.module] === false) {
      warns.push(`功能栏按钮「${b.label}」未生成：模块 ${b.module} 已关闭`);
      continue;
    }
    out.push('<button type="button" class="bs-btn" onclick="' + escAttr(b.fn) + '()">' + escHtml(b.label) + '</button>');
  }
  return out.join('');
}

// 助手面板里的事件词（用于与 -12 正则对齐）
function panelEvents() {
  const all = [];
  for (const k of ['palace', 'territory', 'chaos']) {
    const arr = getPath(config, 'data.helper.evt.' + k);
    if (Array.isArray(arr)) for (const x of arr) all.push(String(x).replace(/^【|】$/g, ''));
  }
  return all;
}

// 1. 模板注入
for (const s of base.regex_scripts) {
  if (typeof s.replaceString === 'string' && /^__TPL__-?\d+__$/.test(s.replaceString)) {
    const id = s.replaceString.match(/^__TPL__(-?\d+)__$/)[1];
    const p = path.join(ROOT, 'src/template', id + '.txt');
    let tpl = fs.readFileSync(p, 'utf8');
    tpl = tpl.replace(/__INJECT__([A-Za-z0-9_.]+)__/g, (m, key) => {
      const v = getPath(config, 'data.' + key);
      if (v === undefined) { errors.push(`配置缺字段 data.${key}（规则 ${id}）`); return m; }
      const slotDef = (manifest.slots || []).find(x => x.key === key);
      if (!slotDef) return toLiteral(v);
      if (slotDef.kind === 'theme') return themeCss(v);
      if (key === 'hud.buttons') return buttonsHtml(v);
      // whole / raw 的槽是 HTML 或源码片段，原样插入，不做 JSON 序列化
      if (slotDef.raw || slotDef.kind === 'whole') return String(v);
      return toLiteral(v);
    });
    s.replaceString = tpl;
  }
  if (/\/\^?/.test(s.findRegex) === false) { /* noop */ }
}

// 2. 正则槽生成
for (const slot of manifest.regexSlots || []) {
  if (slot.kind !== 'event-marks') continue;
  const s = base.regex_scripts.find(x => x.id === slot.id);
  if (!s || s.findRegex !== '__REGEX__' + slot.key + '__') continue;
  const places = getPath(config, 'data.events.places') || [];
  const stored = getPath(config, 'data.events.events') || [];
  const auto = getPath(config, 'data.events.autoSync') !== false;
  let events = stored;
  if (auto) {
    const pan = panelEvents();
    if (pan.length) {
      const merged = stored.slice();
      for (const x of pan) if (merged.indexOf(x) < 0) merged.push(x);
      if (merged.length !== stored.length) {
        warns.push(`-12 事件词表按助手面板补全 ${merged.length - stored.length} 词：` + pan.filter(x => stored.indexOf(x) < 0).join('/'));
      }
      events = merged;
    }
  }
  if (!places.length && !events.length) { errors.push('事件词表为空，-12 规则会是空匹配'); continue; }
  const parts = [];
  if (places.length) parts.push('(?:<#(?:' + places.join('|') + ')>)');
  if (events.length) parts.push('(?:【(?:' + events.join('|') + ')】)');
  s.findRegex = '/(' + parts.join('|') + ')/';
}

// 3. 顶层 meta
for (const k of manifest.metaSlots || []) {
  if (typeof base[k] === 'string' && base[k] === '__META__' + k + '__') {
    const v = getPath(config, 'meta.' + k);
    if (v === undefined) errors.push(`配置缺 meta.${k}`);
    else base[k] = v;
  }
}

// 4. 开场白里必须留着组件锚点，否则整套 UI 都不会加载
const anchors = (base.beginning || '').match(/\{\{[^}]+\}\}/g) || [];
const need = ['slrev-skin', 'st-kit', 'bs-kit', 'mp-kit', 'np-kit', 'slrev-choice-kit', 'evt-kit'];
const lack = need.filter(k => anchors.indexOf('{{' + k + '}}') < 0);
if (lack.length) {
  warns.push('第一句话缺少组件锚点：' + lack.map(k => '{{' + k + '}}').join(' ')
    + '（组件不会加载，除非这些标记由 AI 输出或其他规则产出）');
}

// 5. 体积校验
for (const s of base.regex_scripts) {
  const len = (s.replaceString || '').length;
  if (len > LIMIT) errors.push(`规则 ${s.id} ${s.scriptName}: replaceString ${len} > ${LIMIT}（超 ${len - LIMIT}）`);
  else if (len > LIMIT * 0.95) warns.push(`规则 ${s.id} ${s.scriptName}: ${len} 字，余量仅 ${LIMIT - len}`);
}

const outPath = path.join(ROOT, 'out', outName + '.json');
writeJson(outPath, base);

console.log('== 打包 ' + name + ' ==');
console.log('   规则数:', base.regex_scripts.length);
console.log('   总字符:', base.regex_scripts.reduce((a, s) => a + (s.replaceString || '').length, 0));
base.regex_scripts.forEach(s => {
  const len = (s.replaceString || '').length;
  const bar = len > LIMIT * 0.95 ? ' !' : '';
  console.log('   ', String(s.id).padStart(4), String(s.scriptName).padEnd(22), String(len).padStart(6) + bar);
});
if (warns.length) { console.log('\n-- 提示 --'); warns.forEach(w => console.log('   ' + w)); }
if (errors.length) { console.log('\n-- 错误 --'); errors.forEach(e => console.log('   ' + e)); process.exitCode = 1; }
else console.log('\n输出: ' + outPath);
