document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const settingsToggle = document.getElementById('settings-toggle');
    const settingsPanel = document.getElementById('settings-panel');
    const saveSettingsBtn = document.getElementById('save-settings');
    
    // Tabs
    const tabs = document.querySelectorAll('.tab-link');
    const tabContents = document.querySelectorAll('.tab-content');

    // Upload Tab
    const uploaderPanel = document.getElementById('uploader-panel');
    const resultPanel = document.getElementById('result-panel');
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const uploadProgress = document.getElementById('upload-progress');
    const progressBar = document.getElementById('progress-bar');
    const resultUrlInput = document.getElementById('result-url');
    const copyUrlBtn = document.getElementById('copy-url');

    // Manage Tab
    const refreshListBtn = document.getElementById('refresh-list');
    const fileCountSpan = document.getElementById('file-count');
    const fileListTableBody = document.querySelector('#file-list-table tbody');

    // Config Inputs
    const accountIdInput = document.getElementById('cf-account-id');
    const accessKeyIdInput = document.getElementById('cf-access-key-id');
    const secretAccessKeyInput = document.getElementById('cf-secret-access-key');
    const bucketNameInput = document.getElementById('cf-bucket-name');
    const publicDomainInput = document.getElementById('cf-public-domain');

    let s3;

    // --- Settings Management ---
    function saveSettings() {
        const settings = {
            accountId: accountIdInput.value.trim(),
            accessKeyId: accessKeyIdInput.value.trim(),
            secretAccessKey: secretAccessKeyInput.value.trim(),
            bucketName: bucketNameInput.value.trim(),
            publicDomain: publicDomainInput.value.trim(),
        };

        if (Object.values(settings).some(val => !val)) {
            alert('请填写所有配置项！');
            return;
        }

        localStorage.setItem('r2-uploader-settings', JSON.stringify(settings));
        alert('配置已保存！');
        settingsPanel.classList.add('hidden');
        initializeS3(settings);
    }

    function loadSettings() {
        const savedSettings = localStorage.getItem('r2-uploader-settings');
        if (savedSettings) {
            const settings = JSON.parse(savedSettings);
            accountIdInput.value = settings.accountId;
            accessKeyIdInput.value = settings.accessKeyId;
            secretAccessKeyInput.value = settings.secretAccessKey;
            bucketNameInput.value = settings.bucketName;
            publicDomainInput.value = settings.publicDomain;
            initializeS3(settings);
            return true;
        } else {
            settingsPanel.classList.remove('hidden');
            return false;
        }
    }

    function initializeS3(settings) {
        const { accountId, accessKeyId, secretAccessKey } = settings;
        s3 = new AWS.S3({
            endpoint: `https://${accountId}.r2.cloudflarestorage.com`,
            accessKeyId: accessKeyId,
            secretAccessKey: secretAccessKey,
            signatureVersion: 'v4',
            region: 'auto',
        });
    }

    // --- UI Interactions ---
    settingsToggle.addEventListener('click', () => {
        settingsPanel.classList.toggle('hidden');
    });

    saveSettingsBtn.addEventListener('click', saveSettings);

    copyUrlBtn.addEventListener('click', () => {
        resultUrlInput.select();
        document.execCommand('copy');
        copyUrlBtn.textContent = '已复制!';
        setTimeout(() => { copyUrlBtn.textContent = '复制'; }, 2000);
    });

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            tabContents.forEach(content => content.classList.remove('active'));
            document.getElementById(tab.dataset.tab).classList.add('active');

            if (tab.dataset.tab === 'manage-tab') {
                loadFiles();
            }
        });
    });

    // --- Uploader Logic ---
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileUpload(files[0]);
        }
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileUpload(e.target.files[0]);
        }
    });

    function handleFileUpload(file) {
        if (!s3) {
            alert('请先完成并保存图床配置！');
            settingsPanel.classList.remove('hidden');
            return;
        }

        const bucketName = bucketNameInput.value.trim();
        const publicDomain = publicDomainInput.value.trim();
        const fileName = `${Date.now()}-${file.name}`;

        const params = {
            Bucket: bucketName,
            Key: fileName,
            Body: file,
            ContentType: file.type,
        };

        const upload = s3.upload(params);

        dropZone.style.display = 'none';
        uploadProgress.classList.remove('hidden');
        resultPanel.classList.add('hidden');

        upload.on('httpUploadProgress', (progress) => {
            const percent = Math.round((progress.loaded / progress.total) * 100);
            progressBar.style.width = `${percent}%`;
        });

        upload.promise().then(
            (data) => {
                const fileUrl = `${publicDomain.endsWith('/') ? publicDomain.slice(0, -1) : publicDomain}/${fileName}`;
                resultUrlInput.value = fileUrl;
                uploadProgress.classList.add('hidden');
                resultPanel.classList.remove('hidden');
                dropZone.style.display = 'block';
                progressBar.style.width = '0%';
            },
            (err) => {
                alert(`上传失败: ${err.message}`);
                console.error(err);
                uploadProgress.classList.add('hidden');
                dropZone.style.display = 'block';
                progressBar.style.width = '0%';
            }
        );
    }

    // --- File Management Logic ---
    refreshListBtn.addEventListener('click', loadFiles);

    async function loadFiles() {
        if (!s3) {
            alert('请先完成并保存图床配置！');
            settingsPanel.classList.remove('hidden');
            return;
        }

        fileListTableBody.innerHTML = '<tr><td colspan="4">正在加载...</td></tr>';

        try {
            const data = await s3.listObjectsV2({ Bucket: bucketNameInput.value.trim() }).promise();
            renderFileList(data.Contents);
        } catch (err) {
            alert(`加载文件列表失败: ${err.message}`);
            console.error(err);
            fileListTableBody.innerHTML = '<tr><td colspan="4">加载失败</td></tr>';
        }
    }

    function renderFileList(files) {
        fileListTableBody.innerHTML = '';
        const publicDomain = publicDomainInput.value.trim();

        if (!files || files.length === 0) {
            fileCountSpan.textContent = '共 0 个文件';
            fileListTableBody.innerHTML = '<tr><td colspan="4">存储桶为空</td></tr>';
            return;
        }

        fileCountSpan.textContent = `共 ${files.length} 个文件`;

        files.sort((a, b) => new Date(b.LastModified) - new Date(a.LastModified));

        files.forEach(file => {
            const fileUrl = `${publicDomain.endsWith('/') ? publicDomain.slice(0, -1) : publicDomain}/${file.Key}`;
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><img src="${fileUrl}" alt="预览" class="file-preview"></td>
                <td>${file.Key}</td>
                <td>${new Date(file.LastModified).toLocaleString()}</td>
                <td class="file-actions">
                    <button class="copy-link" data-link="${fileUrl}">复制</button>
                    <button class="delete" data-key="${file.Key}">删除</button>
                </td>
            `;
            fileListTableBody.appendChild(row);
        });
    }

    fileListTableBody.addEventListener('click', (e) => {
        if (e.target.classList.contains('copy-link')) {
            const link = e.target.dataset.link;
            navigator.clipboard.writeText(link).then(() => {
                e.target.textContent = '已复制';
                setTimeout(() => { e.target.textContent = '复制'; }, 2000);
            });
        }

        if (e.target.classList.contains('delete')) {
            const key = e.target.dataset.key;
            if (confirm(`确定要删除文件 ${key} 吗？此操作不可撤销。`)) {
                deleteFile(key);
            }
        }
    });

    async function deleteFile(key) {
        try {
            await s3.deleteObject({ Bucket: bucketNameInput.value.trim(), Key: key }).promise();
            alert('文件删除成功！');
            loadFiles(); // Refresh the list
        } catch (err) {
            alert(`删除失败: ${err.message}`);
            console.error(err);
        }
    }

    // --- Initial Load ---
    loadSettings();
});