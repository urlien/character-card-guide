@echo off
d:
cd "d:\aicunchu\r2-uploader"
echo Starting server...
serve