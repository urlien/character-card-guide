# 原生顶部操作、消息操作与长按菜单

用于全屏 Galgame、沉浸式舞台、顶部返回/评论/分享/收藏/同步换肤，以及长按消息菜单。先区分 **沙盒原生节点** 与 **宿主弹窗**。这是 2026-09-19 用户授权的 Chrome 测试站真实 DOM 观察，非新增 SDK；现有稳定根见[页面结构](../authoring/03-dom.md)，宿主限制见[弹窗探针](host-popup.md)。

## 1. 证据等级与行为

| 区域 | 可复用定位 | 已核实范围 |
| --- | --- | --- |
| 返回 | `[data-chat="header-back"]` | 实际原生按钮；本轮未触发退出 |
| 顶部操作 | `[data-chat="header-actions"] > button[data-action="comments\|share\|favorite\|sync"]` | 四个值分别定位，表中竖线仅简写，不是 CSS 的值匹配语法 |
| 评论 | `data-action="comments"` | 点击进入角色详情评论区，是页面导航；不能承诺留在舞台内弹窗 |
| 分享角色 | 顶部 `data-action="share"` → `[data-host="share-role"]` | 已打开宿主面板，未复制或发送链接 |
| 收藏、同步 | `favorite`、`sync` | 节点已核实；未执行状态变更或同步，不能声称业务验收通过 |
| 消息旁操作 | `[data-chat="message-actions"]` | AI 回复见 regenerate/edit/share；用户消息见 edit/share；首条开场无按钮且没有 data-msg-id |
| 长按菜单 | `[data-chat="message-menu"]` | 用户长按真实 AI 消息打开，见 copy/delete/backtrack/branch；未执行这些业务动作 |

`data-action` 值、`.menu-*` 内部类和默认层级是本轮实现观察，不能自动添加到官方 contract.json。权限、消息状态和首条消息可能影响按钮数量。收藏按钮本轮未见明确 `aria-pressed` / 选中 class，保留原图标，不自造已收藏状态。

## 2. 顶部真实结构

```html
<header data-chat="header">
  <button data-chat="header-back" type="button"><img alt=""></button>
  <div data-chat="header-title"><img><span>角色名</span></div>
  <div data-chat="header-actions">
    <button type="button" data-action="comments" class="header-comments"><img alt=""></button>
    <button type="button" data-action="share"><img alt=""></button>
    <button type="button" data-action="favorite"><img alt=""></button>
    <button type="button" data-action="sync"><img alt=""></button>
  </div>
  <div data-slot="header-extra"></div>
</header>
```

省略运行时资源 URL。保留原生事件、图标和条件徽标；作者只调整位置、间距、背景、边框、尺寸等。不要克隆后认为事件也被复制，不发明 `sdk.openComments`、`sdk.favorite` 等接口。布局可以自定，不强制此案例的双行顶栏。

## 3. 消息与长按菜单真实结构

```html
<div data-chat="message-frame">
  <article data-chat="message" data-from="ai" data-state="done" data-msg-id="运行时消息ID">
    <div data-chat="message-avatar"></div>
    <div data-chat="message-name"></div>
    <div data-chat="message-body">本条渲染结果</div>
    <time data-chat="message-time"></time>
    <div data-chat="message-actions">
      <button type="button" data-action="regenerate"><img alt=""></button>
      <button type="button" data-action="edit"><img alt=""></button>
      <button type="button" data-action="share"><img alt=""></button>
    </div>
    <div data-slot="message-extra"></div>
  </article>
</div>
```

上例仅表示当日有 ID 的普通 AI 回复；不能给首条或没有权限的消息补出不存在的操作。用户消息也有独立原生菜单/权限，不推定与 AI 完全相同。

长按菜单是 **沙盒 root 的后代**，与 header/messages/author-stage/composer 同层附近，不在单条 message-body 内，也不是 `[data-host]`：

```html
<div data-chat="message-menu" style="background-color:rgba(0,0,0,.7)">
  <div class="menu-preview">被选消息的预览</div>
  <div class="menu-options">
    <!-- 观察到条件占位，未知分支不补造 -->
    <button type="button" data-action="copy"><span>复制</span><img alt=""></button>
    <div class="menu-sep"></div>
    <button type="button" data-action="delete"><span>删除</span><img alt=""></button>
    <div class="menu-sep"></div>
    <button type="button" data-action="backtrack"><span>回溯</span><img alt=""></button>
    <div class="menu-sep"></div>
    <button type="button" data-action="branch"><span>开启新的故事</span><img alt=""></button>
  </div>
</div>
```

当日菜单根为 fixed、z-index 8200，菜单预览和操作可分别定制为居中卡片、网格或列表。保留平台菜单根层级，不把它降入作者 1000–1999 段，不修改菜单项真实文案/图标或其确认逻辑。点击遮罩可收起是当日观察；不能凭此假定 Escape 或任意新增关闭按钮存在。

删除/回溯后的确认弹窗内部未打开核对。已开放的 `message-delete`、`message-backtrack`、`message-edit`、`share-records` 仍按各自宿主根处理；`branch` 的后续流程不据按钮文案推导成某个宿主根/API。

## 4. 全屏舞台如何保留长按能力

仅把消息文字复制到 stage，**不会自动带上平台的长按事件**。原生按钮 cloneNode 或重写父级 innerHTML 同样会丢事件。可选方案是以 CSS 把实际原生节点定位到作者 UI 留出的区域，并保留它们原来的父子关系：

1. 舞台保存阅读模型，明确关联当前已挂载的真实 message；历史入口优先保存原节点/消息 ID，切会话清掉关联。正文匹配仅作补充，遇到歧义不能随便绑定到另一条消息。
2. 作者对白在舞台预留尺寸；原消息内的**作者自己创建的正文子节点** fixed 到该区域，保留 message-body/message-frame 的事件冒泡路径。不得改写平台存储的正文或消息 ID，也不移动框架管理节点到 stage。
3. 当日 message-frame/list/messages/root 无 transform、filter、contain 或独立 z-index 祖先，可使用此定位法。新平台需复查包含块/层叠上下文；若受限，保留聊天记录入口，不声称成功。
4. 分页只改变作者正文子节点的显示文本；保留原文，退出、切消息或开作者面板时恢复。平台复制具体取值仍由原业务决定，未实测前不宣称一定复制当前段/整条。
5. 仅暴露目标消息现有的原生 actions，不伪造首条消息 ID、越过禁用状态，或者从其他消息借按钮。原生长按由用户在真实消息子节点上触发，不模拟长按、右键或虚构 SDK。
6. 缩放/尺寸变化时同步对白和操作定位；目标卸载则撤掉浮动节点与透明文字，回退到舞台正文。生成期间撤掉旧消息操作，避免把上一轮当新回复操作。
7. 人物/玩法等作者面板打开时隐藏浮动消息，侧栏和宿主弹窗保持更高层。退出/销毁恢复样式和原文，清理观察者、事件监听和定时任务。

这一方法在雨幕来信 v8 的本地夹具验证了翻页、同一原生节点命中、面板让位、窄屏和退出恢复。真实站只核对原生结构/菜单触发；尚未在平台导入 v8 验证净化、脚本封装或完整长按链路。不能把本地结果写成平台通过。若用户已导入，应继续现场验收。

## 5. 可改写的样式起点

以下仅展示结构定位。颜色、字号、圆角、列数可自由调整；作者 class、舞台尺寸和业务关联需随卡实现。`message-menu` 是平台节点，不能在正则 HTML 自写同名 data 属性冒充它。

```css
[data-chat="message-menu"] {
  display:flex; flex-direction:column; align-items:center;
  justify-content:center; padding:20px; background:#0c202acc;
}
[data-chat="message-menu"] > .menu-preview {
  width:min(680px,100%); box-sizing:border-box;
  max-height:45dvh; overflow:auto; padding:24px;
  background:#eee8d9; color:#2c4842;
  border-radius:12px 12px 0 0;
}
[data-chat="message-menu"] > .menu-options {
  width:min(680px,100%); box-sizing:border-box;
  display:grid; grid-template-columns:repeat(2,minmax(0,1fr));
  gap:8px; padding:16px; background:#19373b;
  border-radius:0 0 12px 12px;
}
[data-chat="message-menu"] .menu-options > button {
  min-height:48px; padding:12px; border:1px solid #acaa8266;
  background:#29473f; color:#ecd5a8;
}
[data-chat="message-menu"] .menu-sep { display:none; }
```

实际原生定位规则可能需要限定覆盖 top/left/transform 和优先级。这些是沙盒内部样式；不要因此覆盖宿主动画 transform。验收长内容滚动、小屏尺寸及遮罩关闭，再检查原按钮的真实状态是否保留。

## 6. 分享角色宿主结构

```html
<uni-view class="share-popup" data-host="share-role">
  <uni-view class="share-title">分享角色</uni-view>
  <uni-view class="share-sub-title">运行时分享链接</uni-view>
  <uni-view class="gen-link-btn" data-host-share-op="copy">
    <uni-image>平台图标</uni-image>复制链接
  </uni-view>
</uni-view>
```

宿主样式须直接从 `[data-host="share-role"]` 起始，例如其后的 `.share-title`、`.share-sub-title`、`[data-host-share-op="copy"]`。此处没有观察到独立关闭按钮，沿用原生遮罩。链接含运行时分享信息，不把用户邀请码或实际 URL 写进模板。跨域宿主只走平台 CSS 注入通道，不能从角色脚本穿透访问。


## 7. v8 导入实测后的修正（2026-09-19）

用户真实导入后，普通 AI 回复的原生三按钮仍存在，但输出没有匹配角色卡的剧情协议，.ym-source/.ym-card-body 未生成。v8 将接入错误地依赖于 ymCurrent 和该正文子节点，导致按钮缺失，长按只落在舞台复制文字。**原生消息操作必须独立于剧情/状态解析是否成功。** 不能把本地标准格式样例通过等同于异常回复也可用。

复用时：

- 初次进入可关联实际已挂载的最新消息；之后按 SDK 消息 ID 与历史入口的真实节点关联，生成中不要操作上一轮，卸载/切会话清理关联。
- 无剧情协议时允许直接重排原生 message-body，保留其内部段落、标签、事件，不清空或重写框架管理的正文。有效作者正文才做分页显示与原文恢复。
- 接入独立使用真实 DOM 和 SDK 事件，避免直接读取其他脚本导出的可变 primitive/DOM 引用来判断状态；如需跨脚本共享，须验证其实际共享机制。
- 本地测试要覆盖无标记回复、格式异常、脚本独立作用域、历史入口、生成/卸载/切会话，不能只将所有脚本拼在一个全局作用域中测试。

真实站已验证原生编辑按钮可打开宿主编辑层，未保存；没有执行破坏性/付费操作。跨脚本执行器实现尚未读取，不能把具体导出机制写成正式契约。v8.1 消除了格式与跨脚本状态依赖，本地复测通过，平台导入后的完整长按链路仍待验收。此记录取代第 4 节把“作者正文子节点存在”作为唯一接入前提的做法；结构图本身仍有效。


## 8. v8.1 失败后的源码核对：查询作用域与两种 ID

2026-09-19 再次读取用户真实页面后，核对该页面公开加载的 `/assets/index-CoRdRBvQ.js`，确认以下机制。此前对跨脚本可变值的怀疑没有构成本次故障的完整解释；以下两点才是已核实的关联失败原因。

- SDK 消息 payload 的 `id` 来自内部 key；历史消息当日形如 `h10494`，另有 `greeting`、本地 key 等。原生 `data-msg-id` 来自 serverId，当日对应 `10494`。挂载事件当前实现还提供 serverId，但某些完成事件只带 id/role/content。**不要把 msg.id 与 data-msg-id 直接比较，也不要固定剪掉一个 h 来兼容所有消息。** 对 SDK 操作继续传 SDK 的原 id，不篡改契约含义。
- 平台不仅对 document.querySelector 做过滤，也对包含消息的祖先 Element.querySelector/querySelectorAll 做过滤。**从 document.body 或 root 开始查询，不会解除消息隔离。** 在 requestAnimationFrame、定时器等脱离消息事件上下文后，全局查询消息可能返回空，尽管浏览器开发工具仍能看到节点。
- 在 `message:mount` 回调内同步查询当前 `[data-chat="message-body"]`，用 `closest('[data-chat="message"]')` 获取其实际原生消息节点，按事件 msg.id 保存关联。该节点的子节点查询与原生事件可以继续保留。延迟布局只使用已取得的节点引用，不再全局扫描消息。清理卸载、断连和切会话记录。
- 不用原始 prototype 方法、隐藏平台状态或内部私有对象绕过查询隔离；也不通过模拟 DOM 事件绕过业务授权。平台允许的消息挂载事件才是获取当前消息引用的入口。
- `message:mount`/`message:done` 可向新订阅者回放已挂载记录；`ready` 与历史挂载的顺序不能假设单一。舞台首次还原也应使用挂载回调收集的节点，不能在 ready 后的 timer 里全局扫消息，否则会一直“等待故事”。

最小节点关联模式（示意，只管理已挂载消息，不读取未挂载历史）：

```js
const messageNodes = new Map();
sdk.on('message:mount', function (msg) {
  const body = document.querySelector('[data-chat="message-body"]');
  const node = body && body.closest('[data-chat="message"]');
  if (msg && node) messageNodes.set(msg.id, node);
});
sdk.on('message:unmount', function (msg) {
  if (msg) messageNodes.delete(msg.id);
});
sdk.on('conversation:switch', function () { messageNodes.clear(); });
sdk.on('dispose', function () { messageNodes.clear(); });
```

本地回归必须包含：事件内部 key 与服务端 DOM ID 不同、消息查询在事件外被过滤、完成事件回放后才 ready、异常剧情格式。v8.2 按此修改消息接入及首次剧情还原。真实平台导入后的验证结果以该次交付记录为准，不将模拟结果等同线上验收。

## 9. 分享聊天记录先进入勾选模式：沉浸舞台必须让位

2026-09-19 用户反馈 v8.2 分享被舞台遮挡；同一公开沙盒资源确认，消息 `message-actions > [data-action="share"]` 首先进入**沙盒的消息选择模式**，不直接打开宿主 `[data-host="share-records"]`。只给宿主弹窗换肤不能解决这个阶段的遮挡。

当日结构（公开客户端实现已核对，非新增正式契约）：

```html
<div data-chat="root" data-share-pick="1">
  <header data-chat="header">
    <button data-chat="share-pick-cancel">取消</button>
    <div data-chat="header-title">角色名</div>
    <button data-chat="share-pick-switch">切换聊天</button>
  </header>
  <!-- 原消息列表内： -->
  <div data-chat="message-frame" data-share-picked="1">
    <button data-chat="share-pick-toggle"><img alt=""></button>
    <!-- 实际原消息 -->
  </div>
  <div data-chat="share-pick-bar">
    <button data-chat="share-pick-link">分享</button>
    <button data-chat="share-pick-image">保存到相册</button>
    <button data-chat="share-pick-comment">分享到评论区</button>
  </div>
</div>
```

`data-share-pick="1"` 只在选择期间出现；选中消息框才有 `data-share-picked="1"`。客户端限制至少 1 条、至多 30 条，以平台未来实际版本为准，不在作者脚本重复实现业务。后续分享链接/保存图片/分享到评论的流程沿用原生事件，不能自动确认或上传。

沉浸卡接入建议：

- 对原生**消息**分享按钮的真实点击先恢复正文与浮动工具栏、同步草稿、关闭作者设置侧栏，再调用自己的退出函数（其中 `sdk.stage.close()`）；不拦截或重发原生点击，不把顶部“分享角色”混在此处理。
- 观察 root 的 `data-share-pick` 变化作为补充。在该属性为 1 时退出舞台；所有打开舞台的入口也检查它。分享时切换聊天不能自动重新覆盖选择页面。
- 分享退出后保留阅读目标、页码和草稿，由用户从“沉浸游玩”主动恢复；不要因取消/节点变化立即自动打开舞台，后续宿主分享层可能仍需显示。
- 浮动原生正文只有在节点仍连接、布局有效时才让舞台副本透明。退出、卸载、人物面板、生成期间均移除透明状态。原生正文不可被清空，作者子节点改过的文字必须恢复。
- CSS 隐藏舞台只能作防闪补充，不能代替关闭舞台和释放浮动节点，否则会残留不可见正文、拦截层或错位按钮。

工具栏独立排版：在对白之后预留不可压缩的一行（尺寸由主题决定），正文滚动区与操作行分开，留分隔线/间距。原生容器 fixed 定位时显式重置 `right/bottom/transform/translate`、最小最大尺寸、盒模型和按钮原位移，避免原平台定位继续生效。响应式可用三列等宽按钮。观察对白、工具栏占位与对话框尺寸，而不只观察全屏舞台尺寸；翻页、字体/窗口变化均可能改变内部位置。

验收至少覆盖：正常与非结构化回复、分享→取消→再次进入、重复分享、草稿保留、窄屏与横屏，检查点击命中的仍是目标原消息。v8.3 本地夹具已覆盖消息查询隔离、不同 ID 与真实分享模式标记；平台浏览器连接本轮不可用，尚未把该模拟通过记为在线导入验收。
