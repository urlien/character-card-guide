// SexyAI HTML渲染器 - 内容脚本
(function() {
    'use strict';

    // HTML渲染器类
    class HTMLRenderer {
        constructor() {
            this.isEnabled = true;
            this.observer = null;
            this.processedElements = new WeakSet();
            this.init();
        }

        init() {
            console.log('SexyAI HTML渲染器已启动');
            this.createToggleButton();
            this.startObserving();
            this.processExistingMessages();
        }

        // 创建切换按钮
        createToggleButton() {
            const button = document.createElement('button');
            button.id = 'html-renderer-toggle';
            button.innerHTML = '🎨';
            button.title = 'HTML渲染器开关';
            button.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10000;
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background: linear-gradient(45deg, #ff6b9d, #4ecdc4);
                border: none;
                color: white;
                font-size: 20px;
                cursor: pointer;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                transition: all 0.3s ease;
            `;
            
            button.addEventListener('click', () => {
                this.toggleRenderer();
            });
            
            document.body.appendChild(button);
        }

        // 切换渲染器状态
        toggleRenderer() {
            this.isEnabled = !this.isEnabled;
            const button = document.getElementById('html-renderer-toggle');
            
            if (this.isEnabled) {
                button.innerHTML = '🎨';
                button.style.opacity = '1';
                this.processExistingMessages();
                console.log('HTML渲染器已启用');
            } else {
                button.innerHTML = '🚫';
                button.style.opacity = '0.6';
                this.restoreOriginalMessages();
                console.log('HTML渲染器已禁用');
            }
        }

        // 开始监听DOM变化
        startObserving() {
            this.observer = new MutationObserver((mutations) => {
                if (!this.isEnabled) return;
                
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            this.processElement(node);
                        }
                    });
                });
            });

            this.observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }

        // 处理现有消息
        processExistingMessages() {
            if (!this.isEnabled) return;
            
            // 查找可能的聊天消息容器
            const messageSelectors = [
                '[class*="message"]',
                '[class*="chat"]',
                '[class*="content"]',
                '[class*="text"]',
                'p', 'div', 'span'
            ];

            messageSelectors.forEach(selector => {
                const elements = document.querySelectorAll(selector);
                elements.forEach(element => {
                    this.processElement(element);
                });
            });
        }

        // 处理单个元素
        processElement(element) {
            if (!this.isEnabled || this.processedElements.has(element)) return;
            
            // 检查是否包含HTML标签
            const textContent = element.textContent || element.innerText || '';
            if (this.containsHTML(textContent)) {
                this.renderHTML(element, textContent);
                this.processedElements.add(element);
            }

            // 递归处理子元素
            const children = element.children;
            for (let i = 0; i < children.length; i++) {
                this.processElement(children[i]);
            }
        }

        // 检查文本是否包含HTML标签
        containsHTML(text) {
            const htmlPattern = /<\/?[a-z][\s\S]*>/i;
            return htmlPattern.test(text);
        }

        // 渲染HTML内容
        renderHTML(element, htmlText) {
            try {
                // 保存原始内容
                if (!element.dataset.originalContent) {
                    element.dataset.originalContent = element.innerHTML;
                }

                // 检查是否包含JavaScript
                const hasScript = htmlText.toLowerCase().includes('<script') || 
                                htmlText.toLowerCase().includes('javascript:') ||
                                /on\w+\s*=/.test(htmlText);

                // 创建渲染容器
                const container = document.createElement('div');
                container.className = 'html-rendered-content';
                container.style.cssText = `
                    max-width: 600px;
                    width: 100%;
                    max-height: 400px;
                    overflow: auto;
                    margin: 10px 0;
                    box-sizing: border-box;
                    position: relative;
                    z-index: 1;
                    display: block;
                    border: 1px solid #e0e0e0;
                    border-radius: 6px;
                    background: #fff;
                `;
                
                // 创建控制面板
                const controlPanel = document.createElement('div');
                controlPanel.style.cssText = `
                    background: #f8f9fa;
                    border: 1px solid #dee2e6;
                    border-radius: 4px;
                    padding: 8px;
                    margin-bottom: 10px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    font-size: 12px;
                `;
                
                controlPanel.innerHTML = `
                    <span style="color: #495057; font-weight: bold;">🎨 HTML渲染内容</span>
                    ${hasScript ? '<span style="background: #fff3cd; color: #856404; padding: 2px 6px; border-radius: 3px;">⚡ 包含交互功能</span>' : ''}
                    <button class="restore-btn" style="background: #6c757d; color: white; border: none; padding: 4px 8px; border-radius: 3px; cursor: pointer; margin-left: auto;">显示原始HTML</button>
                    ${hasScript ? '<button class="interactive-btn" style="background: #28a745; color: white; border: none; padding: 4px 8px; border-radius: 3px; cursor: pointer;">启用交互</button>' : ''}
                `;
                
                container.appendChild(controlPanel);

                // 创建内容区域
                const contentDiv = document.createElement('div');
                contentDiv.style.cssText = `
                    border: 1px solid #dee2e6;
                    border-radius: 4px;
                    padding: 10px;
                    background: white;
                    position: relative;
                    width: 100%;
                    max-height: 350px;
                    overflow: auto;
                    box-sizing: border-box;
                `;
                
                if (hasScript) {
                    // 如果包含JavaScript，创建安全的交互环境
                    this.renderInteractiveHTML(contentDiv, htmlText);
                } else {
                    // 普通HTML直接渲染
                    contentDiv.innerHTML = this.sanitizeHTML(htmlText);
                }
                
                container.appendChild(contentDiv);

                // 绑定事件
                const restoreBtn = controlPanel.querySelector('.restore-btn');
                restoreBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.restoreMessage(element);
                };
                
                const interactiveBtn = controlPanel.querySelector('.interactive-btn');
                if (interactiveBtn) {
                    interactiveBtn.onclick = (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        // 使用原始HTML内容而不是textContent
                        const originalHTML = element.dataset.originalContent || element.innerHTML;
                        this.enableInteractivity(contentDiv, originalHTML);
                        interactiveBtn.textContent = '交互已启用';
                        interactiveBtn.disabled = true;
                        interactiveBtn.style.background = '#6c757d';
                    };
                }

                // 替换原始内容
                element.innerHTML = '';
                element.appendChild(container);

                console.log('HTML内容已渲染:', htmlText.substring(0, 100) + '...');
                if (hasScript) {
                    console.log('🎮 检测到交互内容，可点击"启用交互"按钮体验');
                }
            } catch (error) {
                console.error('HTML渲染失败:', error);
                this.showError(element, error.message);
            }
        }

        // 增强的HTML清理（完整安全措施）
        sanitizeHTML(html) {
            // 移除危险的标签
            const dangerousTags = ['script', 'iframe', 'object', 'embed', 'form', 'meta', 'link', 'style'];
            
            // 移除所有事件处理器属性
            const eventAttrs = [
                'onload', 'onclick', 'onerror', 'onmouseover', 'onmouseout', 'onmousedown', 'onmouseup',
                'onkeydown', 'onkeyup', 'onkeypress', 'onfocus', 'onblur', 'onchange', 'onsubmit',
                'onreset', 'onselect', 'onabort', 'onunload', 'onresize', 'onscroll', 'ondblclick',
                'oncontextmenu', 'ondrag', 'ondrop', 'onwheel', 'ontouchstart', 'ontouchend'
            ];
            
            // 其他危险属性
            const dangerousAttrs = ['javascript:', 'vbscript:', 'data:', 'srcdoc'];
            
            let sanitized = html;
            
            // 移除危险标签及其内容
            dangerousTags.forEach(tag => {
                const regex = new RegExp(`<${tag}[^>]*>.*?<\/${tag}>`, 'gis');
                sanitized = sanitized.replace(regex, '');
                // 移除自闭合标签
                const selfClosingRegex = new RegExp(`<${tag}[^>]*\/>`, 'gi');
                sanitized = sanitized.replace(selfClosingRegex, '');
            });
            
            // 移除所有事件处理器
            eventAttrs.forEach(attr => {
                const regex = new RegExp(`\\s+${attr}\\s*=\\s*["'][^"']*["']`, 'gi');
                sanitized = sanitized.replace(regex, '');
                const regex2 = new RegExp(`\\s+${attr}\\s*=\\s*[^\\s>]+`, 'gi');
                sanitized = sanitized.replace(regex2, '');
            });
            
            // 移除javascript:等危险协议
            dangerousAttrs.forEach(attr => {
                const regex = new RegExp(`${attr}[^\\s"'>]*`, 'gi');
                sanitized = sanitized.replace(regex, '');
            });
            
            // 移除内联JavaScript
            sanitized = sanitized.replace(/javascript:/gi, '');
            sanitized = sanitized.replace(/vbscript:/gi, '');
            
            // 移除script标签但不显示代码内容
            sanitized = sanitized.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
            
            return sanitized;
        }
        
        // HTML转义函数
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // 渲染交互式HTML（预览模式）
        renderInteractiveHTML(container, htmlText) {
            // 先显示静态预览
            const previewDiv = document.createElement('div');
            previewDiv.innerHTML = this.sanitizeHTML(htmlText);
            previewDiv.style.cssText = `
                opacity: 0.7;
                pointer-events: none;
                position: relative;
            `;
            
            // 添加覆盖层提示
            const overlay = document.createElement('div');
            overlay.innerHTML = '🎮 点击"启用交互"按钮体验完整功能';
            overlay.style.cssText = `
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 10px 15px;
                border-radius: 6px;
                font-size: 14px;
                z-index: 10;
                pointer-events: none;
            `;
            
            previewDiv.appendChild(overlay);
            container.appendChild(previewDiv);
        }

        // 启用交互功能
        enableInteractivity(container, htmlText) {
            try {
                // 清空容器
                container.innerHTML = '';
                
                // 创建安全的iframe沙盒
                const iframe = document.createElement('iframe');
                iframe.style.cssText = `
                    width: 100%;
                    min-height: 200px;
                    max-height: 350px;
                    border: none;
                    border-radius: 4px;
                    background: white;
                `;
                
                // 设置沙盒属性以提供安全的执行环境，严格限制在iframe内
                iframe.sandbox = 'allow-scripts allow-forms';
                
                // 创建安全的HTML文档
                const safeHTML = this.createSafeInteractiveHTML(htmlText);
                
                // 使用srcdoc直接设置内容
                iframe.srcdoc = safeHTML;
                
                container.appendChild(iframe);
                
                // 高度由CSS样式控制，避免跨域访问问题
                
                // 监听iframe加载完成
                iframe.onload = () => {
                    console.log('🎮 交互内容加载完成');
                };
                
                console.log('🎮 交互功能已启用');
            } catch (error) {
                console.error('启用交互功能失败:', error);
                container.innerHTML = '<div style="color: #dc3545; padding: 10px;">❌ 交互功能启用失败: ' + error.message + '</div>';
            }
        }

        // 创建安全的交互式HTML
        createSafeInteractiveHTML(htmlText) {
            // 基础的安全HTML模板，添加适当的CSP策略
            const template = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'unsafe-eval'; object-src 'none'; base-uri 'none';">
    <style>
        body {
            margin: 0;
            padding: 5px;
            font-family: Arial, sans-serif;
            background: #fff;
            overflow: auto;
            position: relative;
            max-width: 100%;
            max-height: 100%;
            box-sizing: border-box;
        }
        * {
            box-sizing: border-box;
            max-width: 100%;
        }
        .game-container {
            max-width: 100%;
            margin: 0;
            padding: 10px;
            border: 1px solid #ddd;
            position: relative;
            overflow: auto;
            border-radius: 5px;
            background: #f9f9f9;
        }
        button {
            padding: 4px 8px;
            margin: 2px;
            border: none;
            border-radius: 3px;
            background: #007bff;
            color: white;
            cursor: pointer;
            font-size: 12px;
        }
        button:hover {
            background: #0056b3;
        }
        button:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        .status {
            background: #e9ecef;
            padding: 5px;
            margin: 5px 0;
            border-radius: 3px;
            border-left: 3px solid #007bff;
            font-size: 12px;
        }
        .hp-bar {
            width: 100%;
            height: 15px;
            background: #e9ecef;
            border-radius: 8px;
            overflow: hidden;
            margin: 3px 0;
        }
        .hp-fill {
            height: 100%;
            background: linear-gradient(90deg, #28a745, #20c997);
            transition: width 0.3s ease;
        }
    </style>
</head>
<body>
</body>
</html>`;
            
            // 获取清理后的HTML内容
            const sanitizedContent = this.sanitizeInteractiveHTML(htmlText);
            
            // 将清理后的内容插入到body标签中
            return template.replace('</body>', sanitizedContent + '</body>');
        }

        // 安全化交互式HTML（保留游戏功能）
        sanitizeInteractiveHTML(html) {
            // 只移除最危险的标签
            const dangerousTags = ['iframe', 'object', 'embed'];
            
            // 只禁用最危险的JavaScript函数
            const dangerousJS = [
                'XMLHttpRequest', 'fetch', 'import', 'require',
                'window.location.href', 'document.cookie'
            ];
            
            let sanitized = html;
            
            // 移除危险标签
            dangerousTags.forEach(tag => {
                const regex = new RegExp(`<${tag}[^>]*>.*?<\/${tag}>`, 'gis');
                sanitized = sanitized.replace(regex, '');
                const selfClosingRegex = new RegExp(`<${tag}[^>]*\/>`, 'gi');
                sanitized = sanitized.replace(selfClosingRegex, '');
            });
            
            // 只替换特定的危险调用
            dangerousJS.forEach(func => {
                const regex = new RegExp(`\\b${func.replace('.', '\\.')}\\b`, 'gi');
                sanitized = sanitized.replace(regex, `/* ${func} 已被禁用 */`);
            });
            
            // 移除外部资源引用但保留本地引用
            sanitized = sanitized.replace(/src\s*=\s*["']https?:\/\/[^"']*["']/gi, 'src="#"');
            sanitized = sanitized.replace(/href\s*=\s*["']https?:\/\/[^"']*["']/gi, 'href="#"');
            
            // 确保基本的游戏HTML结构
            if (!sanitized.includes('<div') && !sanitized.includes('<button')) {
                // 如果是纯JavaScript，创建一个基本的游戏界面
                sanitized = '<div class="game-container">' +
                    '<h3>🎮 互动游戏</h3>' +
                    '<div id="gameArea">' +
                        '<div class="status">' +
                            '<div>玩家生命值: <span id="playerHp">100</span>/100</div>' +
                            '<div class="hp-bar"><div class="hp-fill" id="playerHpBar" style="width: 100%"></div></div>' +
                        '</div>' +
                        '<div class="status">' +
                            '<div>敌人: <span id="enemyName">哥布林</span></div>' +
                            '<div>生命值: <span id="enemyHp">60</span>/60</div>' +
                            '<div class="hp-bar"><div class="hp-fill" id="enemyHpBar" style="width: 100%"></div></div>' +
                        '</div>' +
                        '<div style="text-align: center; margin: 20px 0;">' +
                            '<button onclick="attack()">⚔️ 攻击</button>' +
                            '<button onclick="heal()">💚 治疗</button>' +
                            '<button onclick="defend()">🛡️ 防御</button>' +
                        '</div>' +
                        '<div id="gameLog" style="background: #fff; padding: 10px; border-radius: 4px; height: 150px; overflow-y: auto; font-size: 12px;"></div>' +
                    '</div>' +
                '</div>' +
                '<script>' + sanitized + '</script>';
            }
            
            return sanitized;
        }

        // 显示错误信息
        showError(element, message) {
            element.innerHTML = `
                <div class="html-rendered-content" style="border: 2px solid #dc3545; border-radius: 8px; padding: 10px; margin: 5px 0; background: rgba(220, 53, 69, 0.1);">
                    <div style="color: #dc3545; font-weight: bold; margin-bottom: 10px;">❌ HTML渲染失败</div>
                    <div style="background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 10px; border-radius: 4px; margin: 10px 0;">
                        渲染过程中出现错误: ${message}
                    </div>
                    <button onclick="event.preventDefault(); event.stopPropagation(); this.parentElement.parentElement.innerHTML = this.parentElement.parentElement.dataset.originalContent" style="background: #6c757d; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer;">显示原始内容</button>
                </div>
            `;
        }

        // 恢复单个消息
        restoreMessage(element) {
            if (element.dataset.originalContent) {
                element.innerHTML = element.dataset.originalContent;
                delete element.dataset.originalContent;
                this.processedElements.delete(element);
                console.log('已恢复原始HTML内容');
            }
        }

        // 恢复所有原始消息
        restoreOriginalMessages() {
            const renderedElements = document.querySelectorAll('[data-original-content]');
            renderedElements.forEach(element => {
                this.restoreMessage(element);
            });
        }
    }

    // 等待页面加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            new HTMLRenderer();
        });
    } else {
        new HTMLRenderer();
    }

    // 监听来自popup的消息
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'toggleRenderer') {
            const button = document.getElementById('html-renderer-toggle');
            if (button) {
                button.click();
                sendResponse({ success: true });
            } else {
                sendResponse({ success: false, error: '渲染器未初始化' });
            }
        }
    });

})();