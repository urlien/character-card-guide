// SexyAI HTML渲染器 - 后台脚本

// 扩展安装时的初始化
chrome.runtime.onInstalled.addListener((details) => {
    console.log('SexyAI HTML渲染器已安装');
    
    if (details.reason === 'install') {
        // 首次安装时的设置
        chrome.storage.local.set({
            enabled: true,
            autoRender: true,
            safeMode: true
        });
        
        // 打开欢迎页面
        chrome.tabs.create({
            url: 'https://www.sexyai.top/#/'
        });
    }
});

// 处理来自content script的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.action) {
        case 'getSettings':
            chrome.storage.local.get(['enabled', 'autoRender', 'safeMode'], (result) => {
                sendResponse({
                    enabled: result.enabled !== false,
                    autoRender: result.autoRender !== false,
                    safeMode: result.safeMode !== false
                });
            });
            return true;
            
        case 'saveSettings':
            chrome.storage.local.set(request.settings, () => {
                sendResponse({ success: true });
            });
            return true;
            
        case 'logError':
            console.error('HTML渲染器错误:', request.error);
            break;
            
        case 'logInfo':
            console.log('HTML渲染器信息:', request.info);
            break;
    }
});

// 处理扩展图标点击
chrome.action.onClicked.addListener((tab) => {
    // 检查是否在支持的网站上
    if (tab.url && (tab.url.includes('sexyai.top'))) {
        // 向content script发送切换消息
        chrome.tabs.sendMessage(tab.id, {
            action: 'toggleRenderer'
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('无法与content script通信:', chrome.runtime.lastError);
            } else if (response && response.success) {
                console.log('渲染器状态已切换');
            }
        });
    } else {
        // 在不支持的网站上显示通知
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon48.png',
            title: 'SexyAI HTML渲染器',
            message: '此扩展仅在 sexyai.top 网站上工作'
        });
    }
});

// 监听标签页更新
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('sexyai.top')) {
        // 页面加载完成后，确保content script已注入
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
        }).catch((error) => {
            // 忽略已经注入的错误
            if (!error.message.includes('already exists')) {
                console.error('注入content script失败:', error);
            }
        });
    }
});

// 上下文菜单
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: 'toggleHtmlRenderer',
        title: '切换HTML渲染器',
        contexts: ['page'],
        documentUrlPatterns: ['*://www.sexyai.top/*', '*://sexyai.top/*']
    });
    
    chrome.contextMenus.create({
        id: 'renderSelection',
        title: '渲染选中的HTML',
        contexts: ['selection'],
        documentUrlPatterns: ['*://www.sexyai.top/*', '*://sexyai.top/*']
    });
});

// 处理上下文菜单点击
chrome.contextMenus.onClicked.addListener((info, tab) => {
    switch (info.menuItemId) {
        case 'toggleHtmlRenderer':
            chrome.tabs.sendMessage(tab.id, {
                action: 'toggleRenderer'
            });
            break;
            
        case 'renderSelection':
            if (info.selectionText) {
                chrome.tabs.sendMessage(tab.id, {
                    action: 'renderText',
                    text: info.selectionText
                });
            }
            break;
    }
});

// 快捷键处理
chrome.commands.onCommand.addListener((command) => {
    switch (command) {
        case 'toggle-renderer':
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0] && tabs[0].url && tabs[0].url.includes('sexyai.top')) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'toggleRenderer'
                    });
                }
            });
            break;
    }
});

// 定期清理存储
setInterval(() => {
    chrome.storage.local.get(null, (items) => {
        const keys = Object.keys(items);
        if (keys.length > 100) {
            // 如果存储项过多，清理旧数据
            const toRemove = keys.slice(0, keys.length - 50);
            chrome.storage.local.remove(toRemove);
            console.log('已清理旧的存储数据');
        }
    });
}, 24 * 60 * 60 * 1000); // 每24小时检查一次