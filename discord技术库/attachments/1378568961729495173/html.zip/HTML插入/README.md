# SexyAI HTML渲染器

🎨 一个专为 [SexyAI.top](https://www.sexyai.top) 设计的浏览器扩展，让您在聊天对话中直接渲染HTML内容，让交流更加丰富多彩！

## ✨ 功能特性

- 🚀 **实时HTML渲染** - 在聊天框中输入HTML代码即可实时渲染
- 🎯 **智能检测** - 自动识别HTML内容并提供渲染选项
- 🛡️ **安全模式** - 内置HTML净化功能，过滤危险标签和属性
- 🎨 **美观界面** - 现代化的UI设计，完美融入网站风格
- ⚡ **高性能** - 优化的DOM操作，不影响页面性能
- 🔧 **灵活配置** - 丰富的设置选项，满足不同需求

## 🎯 支持的HTML标签

### 基础标签
- `<h1>` - `<h6>` 标题标签
- `<p>` 段落标签
- `<div>` 容器标签
- `<span>` 行内标签
- `<br>` 换行标签
- `<hr>` 分割线

### 文本格式
- `<strong>`, `<b>` 粗体
- `<em>`, `<i>` 斜体
- `<u>` 下划线
- `<s>`, `<del>` 删除线
- `<mark>` 高亮
- `<small>` 小字体
- `<sub>`, `<sup>` 上下标

### 列表和表格
- `<ul>`, `<ol>`, `<li>` 列表
- `<table>`, `<tr>`, `<td>`, `<th>` 表格
- `<thead>`, `<tbody>`, `<tfoot>` 表格结构

### 媒体内容
- `<img>` 图片（支持本地和网络图片）
- `<a>` 链接
- `<video>` 视频（基础支持）
- `<audio>` 音频（基础支持）

### 代码相关
- `<code>` 行内代码
- `<pre>` 预格式化文本
- `<blockquote>` 引用块

### 表单元素
- `<button>` 按钮
- `<input>` 输入框（只读模式）
- `<textarea>` 文本域（只读模式）
- `<select>`, `<option>` 选择框（只读模式）

## 🚀 安装方法

### 方法一：开发者模式安装（推荐）

1. **下载扩展文件**
   - 下载本项目的所有文件到本地文件夹

2. **打开Chrome扩展管理页面**
   - 在Chrome浏览器中输入 `chrome://extensions/`
   - 或者点击右上角菜单 → 更多工具 → 扩展程序

3. **启用开发者模式**
   - 在扩展管理页面右上角打开"开发者模式"开关

4. **加载扩展**
   - 点击"加载已解压的扩展程序"
   - 选择包含扩展文件的文件夹
   - 点击"选择文件夹"

5. **完成安装**
   - 扩展安装成功后会自动打开SexyAI网站
   - 在浏览器工具栏中可以看到扩展图标

### 方法二：打包安装

1. 在扩展管理页面点击"打包扩展程序"
2. 选择扩展文件夹，生成.crx文件
3. 将.crx文件拖拽到扩展管理页面进行安装

## 📖 使用指南

### 基本使用

1. **访问SexyAI网站**
   - 打开 [https://www.sexyai.top](https://www.sexyai.top)
   - 进入任意作品的聊天页面

2. **输入HTML内容**
   ```html
   <h2 style="color: #ff6b9d;">欢迎使用HTML渲染器！</h2>
   <p>这是一个 <strong>粗体文本</strong> 和 <em>斜体文本</em> 的示例。</p>
   <ul>
     <li>功能丰富</li>
     <li>使用简单</li>
     <li>效果出色</li>
   </ul>
   ```

3. **查看渲染效果**
   - 发送消息后，HTML内容会自动渲染
   - 可以点击"显示原始HTML"查看源代码

### 高级功能

#### 样式定制
```html
<div style="
  background: linear-gradient(45deg, #ff6b9d, #4ecdc4);
  padding: 20px;
  border-radius: 10px;
  color: white;
  text-align: center;
">
  <h3>自定义样式卡片</h3>
  <p>支持CSS样式定制</p>
</div>
```

#### 表格展示
```html
<table style="width: 100%; border-collapse: collapse;">
  <thead>
    <tr style="background: #f0f0f0;">
      <th style="border: 1px solid #ddd; padding: 8px;">姓名</th>
      <th style="border: 1px solid #ddd; padding: 8px;">年龄</th>
      <th style="border: 1px solid #ddd; padding: 8px;">城市</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="border: 1px solid #ddd; padding: 8px;">张三</td>
      <td style="border: 1px solid #ddd; padding: 8px;">25</td>
      <td style="border: 1px solid #ddd; padding: 8px;">北京</td>
    </tr>
  </tbody>
</table>
```

#### 代码展示
```html
<pre style="
  background: #2d3748;
  color: #e2e8f0;
  padding: 15px;
  border-radius: 8px;
  overflow-x: auto;
"><code>function greet(name) {
  console.log(`Hello, ${name}!`);
}

greet('World');</code></pre>
```

## ⚙️ 设置选项

### 基本设置
- **启用HTML渲染** - 开启/关闭HTML渲染功能
- **自动渲染新消息** - 新消息自动检测并渲染HTML
- **安全模式** - 启用HTML内容过滤，移除潜在危险标签

### 快捷操作
- **Ctrl + T** - 快速切换渲染器
- **Ctrl + R** - 刷新当前页面
- **点击扩展图标** - 打开设置面板
- **右键菜单** - 快速访问功能

## 🛡️ 安全说明

本扩展内置多重安全保护机制：

1. **HTML净化** - 自动移除危险标签（script, iframe, object等）
2. **属性过滤** - 过滤潜在危险的HTML属性
3. **域名限制** - 仅在SexyAI.top域名下工作
4. **沙盒隔离** - 渲染内容在隔离环境中运行
5. **用户控制** - 用户可随时开启/关闭功能

## 🔧 故障排除

### 常见问题

**Q: 扩展无法正常工作？**
A: 请检查：
- 是否在SexyAI.top网站上
- 扩展是否已启用
- 尝试刷新页面
- 检查浏览器控制台是否有错误信息

**Q: HTML内容没有渲染？**
A: 可能原因：
- 安全模式过滤了某些标签
- HTML语法错误
- 自动渲染功能被关闭

**Q: 样式显示异常？**
A: 建议：
- 使用内联样式而非外部CSS
- 避免使用复杂的CSS选择器
- 检查CSS语法是否正确

### 重置扩展

如果遇到问题，可以尝试重置扩展：
1. 打开扩展设置面板
2. 关闭所有功能
3. 刷新页面
4. 重新启用功能

## 📊 性能优化

- **懒加载** - 仅在需要时渲染HTML内容
- **缓存机制** - 避免重复处理相同内容
- **DOM优化** - 最小化DOM操作次数
- **内存管理** - 及时清理不需要的资源

## 🎨 自定义主题

扩展支持自定义渲染容器的样式，您可以通过修改CSS来调整外观：

```css
.html-rendered-content {
  /* 自定义背景 */
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  
  /* 自定义边框 */
  border: 2px solid #4ecdc4;
  
  /* 自定义阴影 */
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}
```

## 🤝 贡献指南

欢迎提交问题报告和功能建议！

1. Fork 本项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 🙏 致谢

- 感谢 SexyAI.top 提供优秀的平台
- 感谢所有测试用户的反馈和建议
- 感谢开源社区的支持

## 📞 联系我们

如有问题或建议，请通过以下方式联系：

- 📧 邮箱：[your-email@example.com]
- 🐛 问题报告：[GitHub Issues]
- 💬 讨论：[GitHub Discussions]

---

**让聊天更精彩，让创意无限！** ✨

> 本扩展专为SexyAI.top设计，致力于提升用户的聊天体验。我们会持续更新和改进，为您带来更好的功能和体验。