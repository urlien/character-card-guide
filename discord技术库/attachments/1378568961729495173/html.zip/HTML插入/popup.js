// SexyAI HTML渲染器 - 弹出窗口脚本

class PopupController {
    constructor() {
        this.currentTab = null;
        this.settings = {
            enabled: true,
            autoRender: true,
            safeMode: true
        };
        this.stats = {
            renderedCount: 0,
            errorCount: 0
        };
        
        this.init();
    }

    async init() {
        // 获取当前标签页
        await this.getCurrentTab();
        
        // 加载设置和统计
        await this.loadSettings();
        await this.loadStats();
        
        // 初始化UI
        this.initializeUI();
        
        // 绑定事件
        this.bindEvents();
        
        // 检查状态
        this.checkStatus();
    }

    async getCurrentTab() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            this.currentTab = tab;
        } catch (error) {
            console.error('获取当前标签页失败:', error);
        }
    }

    async loadSettings() {
        try {
            const result = await chrome.storage.local.get(['enabled', 'autoRender', 'safeMode']);
            this.settings = {
                enabled: result.enabled !== false,
                autoRender: result.autoRender !== false,
                safeMode: result.safeMode !== false
            };
        } catch (error) {
            console.error('加载设置失败:', error);
        }
    }

    async loadStats() {
        try {
            const result = await chrome.storage.local.get(['renderedCount', 'errorCount']);
            this.stats = {
                renderedCount: result.renderedCount || 0,
                errorCount: result.errorCount || 0
            };
        } catch (error) {
            console.error('加载统计失败:', error);
        }
    }

    async saveSettings() {
        try {
            await chrome.storage.local.set(this.settings);
            
            // 通知content script设置已更改
            if (this.currentTab && this.isValidTab()) {
                chrome.tabs.sendMessage(this.currentTab.id, {
                    action: 'updateSettings',
                    settings: this.settings
                }).catch(() => {
                    // 忽略无法发送消息的错误
                });
            }
        } catch (error) {
            console.error('保存设置失败:', error);
        }
    }

    initializeUI() {
        // 设置开关状态
        document.getElementById('enableRenderer').checked = this.settings.enabled;
        document.getElementById('autoRender').checked = this.settings.autoRender;
        document.getElementById('safeMode').checked = this.settings.safeMode;
        
        // 显示统计信息
        document.getElementById('renderedCount').textContent = this.stats.renderedCount;
        document.getElementById('errorCount').textContent = this.stats.errorCount;
        
        // 检查是否在支持的网站上
        if (!this.isValidTab()) {
            this.showUnsupportedSite();
        }
    }

    bindEvents() {
        // 启用/禁用渲染器
        document.getElementById('enableRenderer').addEventListener('change', (e) => {
            this.settings.enabled = e.target.checked;
            this.saveSettings();
            this.updateStatus();
        });

        // 自动渲染开关
        document.getElementById('autoRender').addEventListener('change', (e) => {
            this.settings.autoRender = e.target.checked;
            this.saveSettings();
        });

        // 安全模式开关
        document.getElementById('safeMode').addEventListener('change', (e) => {
            this.settings.safeMode = e.target.checked;
            this.saveSettings();
        });

        // 切换按钮
        document.getElementById('toggleButton').addEventListener('click', () => {
            this.toggleRenderer();
        });

        // 刷新按钮
        document.getElementById('refreshButton').addEventListener('click', () => {
            this.refreshPage();
        });

        // 监听存储变化
        chrome.storage.onChanged.addListener((changes) => {
            if (changes.renderedCount || changes.errorCount) {
                this.loadStats().then(() => {
                    document.getElementById('renderedCount').textContent = this.stats.renderedCount;
                    document.getElementById('errorCount').textContent = this.stats.errorCount;
                });
            }
        });
    }

    isValidTab() {
        return this.currentTab && 
               this.currentTab.url && 
               (this.currentTab.url.includes('sexyai.top'));
    }

    showUnsupportedSite() {
        const statusText = document.getElementById('statusText');
        const statusIndicator = document.getElementById('statusIndicator');
        const toggleButton = document.getElementById('toggleButton');
        
        statusText.textContent = '不支持的网站';
        statusIndicator.className = 'status-indicator inactive';
        toggleButton.disabled = true;
        toggleButton.textContent = '仅支持 sexyai.top';
        toggleButton.style.opacity = '0.5';
        
        // 禁用所有控件
        document.querySelectorAll('input[type="checkbox"]').forEach(input => {
            input.disabled = true;
        });
    }

    async checkStatus() {
        if (!this.isValidTab()) {
            return;
        }

        try {
            const response = await chrome.tabs.sendMessage(this.currentTab.id, {
                action: 'getStatus'
            });
            
            if (response && response.success) {
                this.updateStatusUI(response.enabled, response.active);
            } else {
                this.updateStatusUI(false, false);
            }
        } catch (error) {
            console.error('检查状态失败:', error);
            this.updateStatusUI(false, false);
        }
    }

    updateStatusUI(enabled, active) {
        const statusText = document.getElementById('statusText');
        const statusIndicator = document.getElementById('statusIndicator');
        
        if (enabled && active) {
            statusText.textContent = '渲染器已启用';
            statusIndicator.className = 'status-indicator active';
        } else if (enabled && !active) {
            statusText.textContent = '渲染器已禁用';
            statusIndicator.className = 'status-indicator inactive';
        } else {
            statusText.textContent = '渲染器未加载';
            statusIndicator.className = 'status-indicator inactive';
        }
    }

    updateStatus() {
        this.checkStatus();
    }

    async toggleRenderer() {
        if (!this.isValidTab()) {
            return;
        }

        try {
            const response = await chrome.tabs.sendMessage(this.currentTab.id, {
                action: 'toggleRenderer'
            });
            
            if (response && response.success) {
                // 更新状态显示
                setTimeout(() => this.checkStatus(), 100);
                
                // 显示反馈
                this.showFeedback(response.enabled ? '渲染器已启用' : '渲染器已禁用');
            } else {
                this.showFeedback('操作失败，请刷新页面重试', 'error');
            }
        } catch (error) {
            console.error('切换渲染器失败:', error);
            this.showFeedback('无法与页面通信，请刷新页面', 'error');
        }
    }

    async refreshPage() {
        if (!this.isValidTab()) {
            return;
        }

        try {
            await chrome.tabs.reload(this.currentTab.id);
            this.showFeedback('页面已刷新');
            
            // 关闭弹出窗口
            setTimeout(() => window.close(), 500);
        } catch (error) {
            console.error('刷新页面失败:', error);
            this.showFeedback('刷新失败', 'error');
        }
    }

    showFeedback(message, type = 'success') {
        // 创建反馈元素
        const feedback = document.createElement('div');
        feedback.style.cssText = `
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: ${type === 'error' ? '#f44336' : '#4CAF50'};
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            z-index: 1000;
            animation: slideDown 0.3s ease;
        `;
        feedback.textContent = message;
        
        // 添加动画样式
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideDown {
                from { opacity: 0; transform: translateX(-50%) translateY(-20px); }
                to { opacity: 1; transform: translateX(-50%) translateY(0); }
            }
        `;
        document.head.appendChild(style);
        
        document.body.appendChild(feedback);
        
        // 3秒后移除
        setTimeout(() => {
            if (feedback.parentNode) {
                feedback.remove();
            }
            if (style.parentNode) {
                style.remove();
            }
        }, 3000);
    }
}

// 当弹出窗口加载完成时初始化
document.addEventListener('DOMContentLoaded', () => {
    new PopupController();
});

// 处理快捷键
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        document.getElementById('refreshButton').click();
    } else if (e.ctrlKey && e.key === 't') {
        e.preventDefault();
        document.getElementById('toggleButton').click();
    }
});