// 简化的背景脚本，用于测试
console.log('SexyAI 扩展背景脚本已加载');

// 扩展安装时的初始化
chrome.runtime.onInstalled.addListener((details) => {
    console.log('SexyAI 共享留言板扩展已安装');
    
    // 设置默认配置
    const defaultSettings = {
        position: 'right-side',
        theme: 'dark',
        showByDefault: false,
        allowAnonymous: true,
        autoRefresh: true,
        refreshInterval: 30000,
        enableNotifications: true,
        maxCommentsDisplay: 50
    };
    
    // 保存默认设置
    chrome.storage.sync.set({ sexyaiCommentSettings: defaultSettings });
});

// 处理扩展图标点击事件
chrome.action.onClicked.addListener((tab) => {
    // 向当前标签页发送切换留言板的消息
    chrome.tabs.sendMessage(tab.id, {
        action: 'toggleCommentBoard'
    }).catch(() => {
        // 如果内容脚本未加载，忽略错误
        console.log('内容脚本未在此页面加载');
    });
});

// 处理来自内容脚本的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.action) {
        case 'getSettings':
            chrome.storage.sync.get(['sexyaiCommentSettings'], (result) => {
                sendResponse(result.sexyaiCommentSettings || {});
            });
            return true; // 保持消息通道开放
            
        case 'saveSettings':
            chrome.storage.sync.set({ sexyaiCommentSettings: request.settings }, () => {
                sendResponse({ success: true });
            });
            return true;
            
        default:
            sendResponse({ error: 'Unknown action' });
    }
});

// 处理popup连接
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'popup') {
        port.onMessage.addListener((msg) => {
            switch (msg.action) {
                case 'getStats':
                    // 获取统计信息
                    chrome.storage.local.get(['sexyaiStats'], (result) => {
                        const stats = result.sexyaiStats || {
                            commentsPosted: 0,
                            sitesVisited: 0
                        };
                        port.postMessage({ action: 'stats', data: stats });
                    });
                    break;
                    
                case 'exportSettings':
                    // 导出设置
                    chrome.storage.sync.get(['sexyaiCommentSettings'], (result) => {
                        const exportData = {
                            settings: result.sexyaiCommentSettings || {},
                            exportDate: new Date().toISOString(),
                            version: '1.0.0'
                        };
                        port.postMessage({ action: 'exportData', data: exportData });
                    });
                    break;
                    
                case 'importSettings':
                    // 导入设置
                    try {
                        const importData = msg.data;
                        if (importData.settings) {
                            chrome.storage.sync.set({ sexyaiCommentSettings: importData.settings }, () => {
                                port.postMessage({ action: 'importSuccess' });
                            });
                        } else {
                            port.postMessage({ action: 'importError', error: '无效的设置数据' });
                        }
                    } catch (error) {
                        port.postMessage({ action: 'importError', error: error.message });
                    }
                    break;
            }
        });
    }
});