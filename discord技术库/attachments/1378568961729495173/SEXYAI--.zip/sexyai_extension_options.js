// SexyAI 共享留言板 - 选项页面脚本
// 处理详细设置的管理和用户交互

class OptionsManager {
    constructor() {
        this.settings = {};
        this.stats = {};
        this.defaultSettings = {
            position: 'right-side',
            theme: 'dark',
            showByDefault: false,
            allowAnonymous: true,
            autoRefresh: true,
            refreshInterval: 30000,
            enableNotifications: true,
            maxCommentsDisplay: 50,
            primaryColor: '#667eea',
            opacity: 0.9,
            borderRadius: 12,
            fontSize: 14,
            debugMode: false,
            customCSS: '',
            apiEndpoint: '',
            firebaseConfig: ''
        };
        
        this.init();
    }

    async init() {
        try {
            await this.loadSettings();
            await this.loadStats();
            this.initializeUI();
            this.bindEventListeners();
            this.updateStatsDisplay();
        } catch (error) {
            console.error('初始化失败:', error);
            this.showMessage('初始化失败，请刷新页面重试', 'error');
        }
    }

    async loadSettings() {
        return new Promise((resolve) => {
            chrome.storage.sync.get(['sexyaiCommentSettings'], (result) => {
                this.settings = { ...this.defaultSettings, ...(result.sexyaiCommentSettings || {}) };
                resolve(this.settings);
            });
        });
    }

    async saveSettings() {
        return new Promise((resolve) => {
            chrome.storage.sync.set({ sexyaiCommentSettings: this.settings }, () => {
                this.showMessage('设置已保存', 'success');
                resolve(true);
            });
        });
    }

    async loadStats() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['extensionStats'], (result) => {
                this.stats = result.extensionStats || {
                    installDate: Date.now(),
                    commentsPosted: 0,
                    sitesVisited: 0,
                    likesReceived: 0,
                    activeDays: 0,
                    lastUsed: Date.now()
                };
                resolve(this.stats);
            });
        });
    }

    initializeUI() {
        // 基本设置
        this.updateToggle('autoShow', this.settings.showByDefault);
        this.updateToggle('allowAnonymous', this.settings.allowAnonymous);
        this.updateToggle('autoRefresh', this.settings.autoRefresh);
        this.updateToggle('enableNotifications', this.settings.enableNotifications);
        this.updateToggle('debugMode', this.settings.debugMode);
        
        // 下拉选择
        document.getElementById('position').value = this.settings.position;
        document.getElementById('theme').value = this.settings.theme;
        
        // 滑块设置
        this.updateSlider('refreshInterval', this.settings.refreshInterval / 1000, 'refreshIntervalValue', (val) => `${val}秒`);
        this.updateSlider('maxComments', this.settings.maxCommentsDisplay, 'maxCommentsValue');
        this.updateSlider('opacity', this.settings.opacity, 'opacityValue');
        this.updateSlider('borderRadius', this.settings.borderRadius, 'borderRadiusValue', (val) => `${val}px`);
        this.updateSlider('fontSize', this.settings.fontSize, 'fontSizeValue', (val) => `${val}px`);
        
        // 颜色选择
        this.updateColorPicker('primaryColor', this.settings.primaryColor);
        
        // 文本区域
        document.getElementById('customCSS').value = this.settings.customCSS || '';
        document.getElementById('apiEndpoint').value = this.settings.apiEndpoint || '';
        document.getElementById('firebaseConfig').value = this.settings.firebaseConfig || '';
        
        // 高级设置折叠状态
        this.initializeCollapsible();
    }

    updateToggle(id, active) {
        const toggle = document.getElementById(id);
        if (toggle) {
            toggle.classList.toggle('active', active);
        }
    }

    updateSlider(id, value, valueId, formatter = null) {
        const slider = document.getElementById(id);
        const valueDisplay = document.getElementById(valueId);
        
        if (slider && valueDisplay) {
            slider.value = value;
            valueDisplay.textContent = formatter ? formatter(value) : value;
        }
    }

    updateColorPicker(id, selectedColor) {
        const colorPicker = document.getElementById(id);
        if (colorPicker) {
            const options = colorPicker.querySelectorAll('.color-option');
            options.forEach(option => {
                option.classList.toggle('selected', option.dataset.color === selectedColor);
            });
        }
    }

    initializeCollapsible() {
        const advancedToggle = document.getElementById('advancedToggle');
        const advancedContent = document.getElementById('advancedContent');
        
        // 默认折叠
        advancedToggle.classList.add('collapsed');
        advancedContent.classList.add('collapsed');
    }

    updateStatsDisplay() {
        document.getElementById('totalComments').textContent = this.stats.commentsPosted || 0;
        document.getElementById('totalVisits').textContent = this.stats.sitesVisited || 0;
        document.getElementById('totalLikes').textContent = this.stats.likesReceived || 0;
        document.getElementById('activeDays').textContent = this.stats.activeDays || 0;
    }

    bindEventListeners() {
        // 切换开关事件
        this.bindToggleEvents();
        
        // 下拉选择事件
        this.bindSelectEvents();
        
        // 滑块事件
        this.bindSliderEvents();
        
        // 颜色选择事件
        this.bindColorPickerEvents();
        
        // 按钮事件
        this.bindButtonEvents();
        
        // 文本区域事件
        this.bindTextAreaEvents();
        
        // 高级设置折叠事件
        this.bindCollapsibleEvents();
        
        // 文件导入事件
        this.bindFileEvents();
    }

    bindToggleEvents() {
        const toggles = ['autoShow', 'allowAnonymous', 'autoRefresh', 'enableNotifications', 'debugMode'];
        
        toggles.forEach(id => {
            const toggle = document.getElementById(id);
            if (toggle) {
                toggle.addEventListener('click', () => {
                    const settingKey = this.getSettingKey(id);
                    this.settings[settingKey] = !this.settings[settingKey];
                    this.updateToggle(id, this.settings[settingKey]);
                });
            }
        });
    }

    bindSelectEvents() {
        document.getElementById('position').addEventListener('change', (e) => {
            this.settings.position = e.target.value;
        });

        document.getElementById('theme').addEventListener('change', (e) => {
            this.settings.theme = e.target.value;
        });
    }

    bindSliderEvents() {
        const sliders = [
            { id: 'refreshInterval', key: 'refreshInterval', multiplier: 1000, formatter: (val) => `${val}秒` },
            { id: 'maxComments', key: 'maxCommentsDisplay', formatter: null },
            { id: 'opacity', key: 'opacity', formatter: null },
            { id: 'borderRadius', key: 'borderRadius', formatter: (val) => `${val}px` },
            { id: 'fontSize', key: 'fontSize', formatter: (val) => `${val}px` }
        ];

        sliders.forEach(({ id, key, multiplier = 1, formatter }) => {
            const slider = document.getElementById(id);
            const valueDisplay = document.getElementById(id + 'Value');
            
            if (slider && valueDisplay) {
                slider.addEventListener('input', (e) => {
                    const value = parseFloat(e.target.value);
                    this.settings[key] = value * multiplier;
                    valueDisplay.textContent = formatter ? formatter(value) : value;
                });
            }
        });
    }

    bindColorPickerEvents() {
        const colorPicker = document.getElementById('primaryColor');
        if (colorPicker) {
            colorPicker.addEventListener('click', (e) => {
                if (e.target.classList.contains('color-option')) {
                    const color = e.target.dataset.color;
                    this.settings.primaryColor = color;
                    this.updateColorPicker('primaryColor', color);
                }
            });
        }
    }

    bindButtonEvents() {
        document.getElementById('saveSettings').addEventListener('click', () => {
            this.saveSettings();
        });

        document.getElementById('exportSettings').addEventListener('click', () => {
            this.exportSettings();
        });

        document.getElementById('resetSettings').addEventListener('click', () => {
            this.resetSettings();
        });

        document.getElementById('clearData').addEventListener('click', () => {
            this.clearData();
        });

        document.getElementById('previewChanges').addEventListener('click', () => {
            this.previewChanges();
        });

        document.getElementById('openHelp').addEventListener('click', () => {
            chrome.tabs.create({ url: 'https://github.com/your-repo/sexyai-comment-board/wiki' });
        });
    }

    bindTextAreaEvents() {
        document.getElementById('customCSS').addEventListener('input', (e) => {
            this.settings.customCSS = e.target.value;
        });

        document.getElementById('apiEndpoint').addEventListener('input', (e) => {
            this.settings.apiEndpoint = e.target.value;
        });

        document.getElementById('firebaseConfig').addEventListener('input', (e) => {
            this.settings.firebaseConfig = e.target.value;
        });
    }

    bindCollapsibleEvents() {
        const advancedToggle = document.getElementById('advancedToggle');
        const advancedContent = document.getElementById('advancedContent');
        
        advancedToggle.addEventListener('click', () => {
            const isCollapsed = advancedToggle.classList.contains('collapsed');
            advancedToggle.classList.toggle('collapsed', !isCollapsed);
            advancedContent.classList.toggle('collapsed', !isCollapsed);
        });
    }

    bindFileEvents() {
        const importFile = document.getElementById('importFile');
        importFile.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                this.importSettings(file);
            }
        });

        // 拖拽导入
        document.addEventListener('dragover', (e) => {
            e.preventDefault();
        });

        document.addEventListener('drop', (e) => {
            e.preventDefault();
            const files = e.dataTransfer.files;
            if (files.length > 0 && files[0].type === 'application/json') {
                this.importSettings(files[0]);
            }
        });
    }

    getSettingKey(toggleId) {
        const keyMap = {
            'autoShow': 'showByDefault',
            'allowAnonymous': 'allowAnonymous',
            'autoRefresh': 'autoRefresh',
            'enableNotifications': 'enableNotifications',
            'debugMode': 'debugMode'
        };
        return keyMap[toggleId] || toggleId;
    }

    exportSettings() {
        const exportData = {
            version: chrome.runtime.getManifest().version,
            timestamp: Date.now(),
            settings: this.settings,
            stats: this.stats
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `sexyai-comment-board-settings-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showMessage('设置已导出', 'success');
    }

    importSettings(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importData = JSON.parse(e.target.result);
                
                if (importData.settings) {
                    this.settings = { ...this.defaultSettings, ...importData.settings };
                    this.initializeUI();
                    this.showMessage('设置导入成功！', 'success');
                } else {
                    this.showMessage('文件格式错误：缺少设置数据', 'error');
                }
            } catch (error) {
                this.showMessage('文件格式错误：无法解析JSON', 'error');
            }
        };
        reader.readAsText(file);
    }

    resetSettings() {
        if (confirm('确定要重置所有设置吗？此操作无法撤销。')) {
            this.settings = { ...this.defaultSettings };
            this.initializeUI();
            this.saveSettings();
            this.showMessage('设置已重置', 'success');
        }
    }

    clearData() {
        if (confirm('确定要清除所有数据吗？这将删除缓存、统计信息等。')) {
            chrome.storage.local.clear(() => {
                this.stats = {
                    installDate: Date.now(),
                    commentsPosted: 0,
                    sitesVisited: 0,
                    likesReceived: 0,
                    activeDays: 0,
                    lastUsed: Date.now()
                };
                this.updateStatsDisplay();
                this.showMessage('数据已清除', 'success');
            });
        }
    }

    previewChanges() {
        // 查找当前打开的 SexyAI 标签页
        chrome.tabs.query({ url: ['https://www.sexyai.top/*', 'https://sexyai.top/*'] }, (tabs) => {
            if (tabs.length > 0) {
                // 向内容脚本发送预览设置
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'previewSettings',
                    settings: this.settings
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        this.showMessage('无法连接到 SexyAI 页面，请确保页面已打开', 'error');
                    } else {
                        this.showMessage('预览效果已应用到 SexyAI 页面', 'success');
                    }
                });
            } else {
                this.showMessage('请先打开 SexyAI 网站页面', 'info');
            }
        });
    }

    showMessage(text, type = 'info') {
        const messageArea = document.getElementById('messageArea');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = text;
        
        messageArea.innerHTML = '';
        messageArea.appendChild(messageDiv);
        
        // 3秒后自动清除消息
        setTimeout(() => {
            if (messageArea.contains(messageDiv)) {
                messageArea.removeChild(messageDiv);
            }
        }, 3000);
    }

    // 验证 Firebase 配置
    validateFirebaseConfig(configText) {
        try {
            const config = JSON.parse(configText);
            const requiredFields = ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId'];
            
            for (const field of requiredFields) {
                if (!config[field]) {
                    return { valid: false, error: `缺少必需字段: ${field}` };
                }
            }
            
            return { valid: true, config };
        } catch (error) {
            return { valid: false, error: 'JSON 格式错误' };
        }
    }

    // 测试 API 连接
    async testApiConnection(endpoint) {
        try {
            const response = await fetch(endpoint + '/health', {
                method: 'GET',
                timeout: 5000
            });
            
            if (response.ok) {
                return { success: true, message: 'API 连接成功' };
            } else {
                return { success: false, message: `API 返回错误: ${response.status}` };
            }
        } catch (error) {
            return { success: false, message: `连接失败: ${error.message}` };
        }
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    new OptionsManager();
});

// 键盘快捷键
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
            case 's':
                e.preventDefault();
                document.getElementById('saveSettings').click();
                break;
            case 'e':
                e.preventDefault();
                document.getElementById('exportSettings').click();
                break;
            case 'r':
                e.preventDefault();
                if (e.shiftKey) {
                    document.getElementById('resetSettings').click();
                }
                break;
        }
    }
});

// 全局错误处理
window.addEventListener('error', (e) => {
    console.error('选项页面错误:', e.error);
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('未处理的Promise拒绝:', e.reason);
});