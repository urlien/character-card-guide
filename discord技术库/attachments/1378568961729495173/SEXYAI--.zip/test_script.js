let clickCount = 0;

function testClick() {
    clickCount++;
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = 
        '按钮已点击 ' + clickCount + ' 次<br>时间: ' + new Date().toLocaleTimeString();
}

// 页面加载完成后绑定事件
document.addEventListener('DOMContentLoaded', function() {
    const button = document.getElementById('testButton');
    const resultDiv = document.getElementById('result');
    
    if (button && resultDiv) {
        button.addEventListener('click', testClick);
        resultDiv.textContent = '页面已加载，可以测试';
    }
});