// SexyAI 共享留言板 - 内容脚本
// 使用 Firebase 实现云端数据同步

(function() {
    'use strict';

    // Firebase 配置 - 已配置实际的项目信息
    let firebaseConfig = {
        apiKey: "AIzaSyAXVX6UEve7s08IyyLeFkNOLtc7f-TFPrw",
        authDomain: "sexyai-comment-board.firebaseapp.com",
        databaseURL: "https://sexyai-comment-board-default-rtdb.asia-southeast1.firebasedatabase.app",
        projectId: "sexyai-comment-board",
        storageBucket: "sexyai-comment-board.firebasestorage.app",
        messagingSenderId: "784844164335",
        appId: "1:784844164335:web:6caee469f82c88461f1f1a"
    };
    
    // 默认使用云存储，让所有用户共享评论数据
    let useCloudStorage = true;

    // 本地存储类（备用方案）
    class LocalCommentStorage {
        constructor() {
            this.storageKey = 'sexyai_comments_';
        }

        // 获取评论
        async getComments(workId) {
            try {
                const key = this.storageKey + workId;
                const result = await new Promise((resolve) => {
                    chrome.storage.local.get([key], (result) => {
                        resolve(result[key] || []);
                    });
                });
                return result.sort((a, b) => a.timestamp - b.timestamp);
            } catch (error) {
                console.error('获取本地评论失败:', error);
                return [];
            }
        }

        // 添加评论
        async addComment(workId, comment) {
            try {
                const comments = await this.getComments(workId);
                const newComment = {
                    ...comment,
                    id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
                };
                comments.push(newComment);
                
                const key = this.storageKey + workId;
                await new Promise((resolve) => {
                    chrome.storage.local.set({ [key]: comments }, resolve);
                });
                
                return { name: newComment.id };
            } catch (error) {
                console.error('添加本地评论失败:', error);
                throw error;
            }
        }

        // 删除评论
        async deleteComment(workId, commentId) {
            try {
                const comments = await this.getComments(workId);
                const filteredComments = comments.filter(c => c.id !== commentId);
                
                const key = this.storageKey + workId;
                await new Promise((resolve) => {
                    chrome.storage.local.set({ [key]: filteredComments }, resolve);
                });
            } catch (error) {
                console.error('删除本地评论失败:', error);
                throw error;
            }
        }

        // 点赞评论
        async likeComment(workId, commentId, likes) {
            try {
                const comments = await this.getComments(workId);
                const comment = comments.find(c => c.id === commentId);
                if (comment) {
                    comment.likes = likes;
                    const key = this.storageKey + workId;
                    await new Promise((resolve) => {
                        chrome.storage.local.set({ [key]: comments }, resolve);
                    });
                }
            } catch (error) {
                console.error('本地点赞失败:', error);
                throw error;
            }
        }

        // 获取作品统计信息
        async getWorkStats(workId) {
            try {
                const comments = await this.getComments(workId);
                return {
                    views: Math.floor(Math.random() * 100) + comments.length * 5,
                    comments: comments.length,
                    likes: comments.reduce((sum, c) => sum + (c.likes || 0), 0)
                };
            } catch (error) {
                console.error('获取本地统计信息失败:', error);
                return { views: 0, comments: 0, likes: 0 };
            }
        }

        // 更新作品统计信息
        async updateWorkStats(workId, stats) {
            // 本地存储模式下不需要单独更新统计信息
            return Promise.resolve();
        }
    }

    // 云端存储类
    class CloudCommentStorage {
        constructor() {
            this.baseUrl = firebaseConfig.databaseURL;
            this.apiKey = firebaseConfig.apiKey;
            this.isConfigured = this.checkConfiguration();
            this.connectionTested = false;
            this.isConnected = false;
        }
        
        // 检查Firebase配置是否有效 - 强制返回true以使用共享云数据库
        checkConfiguration() {
            // 始终返回true，使用预配置的Firebase数据库让所有用户共享评论
            return true;
        }

        // 测试连接
        async testConnection() {
            if (this.connectionTested) {
                return this.isConnected;
            }

            try {
                const testUrl = `${this.baseUrl}/.json?auth=${this.apiKey}&shallow=true`;
                const response = await fetch(testUrl, {
                    method: 'GET',
                    timeout: 5000 // 5秒超时
                });
                
                // 401错误通常表示数据库存在但规则限制访问，仍认为连接成功
                this.isConnected = response.ok || response.status === 401;
                this.connectionTested = true;
                
                if (response.status === 401) {
                    console.warn('Firebase返回401错误，可能需要修改数据库规则以允许访问');
                } else if (!response.ok) {
                    console.warn('Firebase连接测试失败:', response.status, response.statusText);
                }
                
                return this.isConnected;
            } catch (error) {
                console.error('Firebase连接测试异常:', error);
                this.isConnected = false;
                this.connectionTested = true;
                return false;
            }
        }

        // 获取评论
        async getComments(workId) {
            try {
                const response = await fetch(`${this.baseUrl}/comments/${workId}.json?auth=${this.apiKey}`);
                const data = await response.json();
                return data ? Object.values(data).sort((a, b) => a.timestamp - b.timestamp) : [];
            } catch (error) {
                console.error('获取评论失败:', error);
                return [];
            }
        }

        // 添加评论
        async addComment(workId, comment) {
            try {
                const response = await fetch(`${this.baseUrl}/comments/${workId}.json?auth=${this.apiKey}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(comment)
                });
                return await response.json();
            } catch (error) {
                console.error('添加评论失败:', error);
                throw error;
            }
        }

        // 删除评论
        async deleteComment(workId, commentKey) {
            try {
                await fetch(`${this.baseUrl}/comments/${workId}/${commentKey}.json?auth=${this.apiKey}`, {
                    method: 'DELETE'
                });
            } catch (error) {
                console.error('删除评论失败:', error);
                throw error;
            }
        }

        // 点赞评论
        async likeComment(workId, commentKey, likes) {
            try {
                await fetch(`${this.baseUrl}/comments/${workId}/${commentKey}/likes.json?auth=${this.apiKey}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(likes)
                });
            } catch (error) {
                console.error('点赞失败:', error);
                throw error;
            }
        }

        // 获取作品统计信息
        async getWorkStats(workId) {
            try {
                const response = await fetch(`${this.baseUrl}/stats/${workId}.json?auth=${this.apiKey}`);
                const data = await response.json();
                return data || { views: 0, comments: 0, likes: 0 };
            } catch (error) {
                console.error('获取统计信息失败:', error);
                return { views: 0, comments: 0, likes: 0 };
            }
        }

        // 更新作品统计信息
        async updateWorkStats(workId, stats) {
            try {
                await fetch(`${this.baseUrl}/stats/${workId}.json?auth=${this.apiKey}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(stats)
                });
            } catch (error) {
                console.error('更新统计信息失败:', error);
            }
        }
    }

    // 初始化存储系统 - 默认使用云存储实现评论共享
    async function initializeStorage() {
        const cloudStorage = new CloudCommentStorage();
        // 强制使用云存储，让所有用户共享评论数据
        try {
            // 测试Firebase连接
            const isConnected = await cloudStorage.testConnection();
            if (isConnected) {
                console.log('使用云端存储 (Firebase) - 连接正常，所有用户共享评论数据');
                useCloudStorage = true;
                return cloudStorage;
            } else {
                console.warn('Firebase连接失败，但仍尝试使用云存储');
                useCloudStorage = true;
                return cloudStorage; // 即使连接测试失败也使用云存储
            }
        } catch (error) {
            console.error('云存储初始化异常，降级到本地存储:', error);
            useCloudStorage = false;
            return new LocalCommentStorage();
        }
    }

    // 全局变量
    let storage = null; // 将在init函数中异步初始化
    let currentWorkId = null;
    let commentBoard = null;
    let isMinimized = false;
    // 固定配置 - 用户无法修改，确保统一的使用体验
    let settings = {
        position: 'right-side',
        theme: 'dark',
        showByDefault: false,
        allowAnonymous: true,
        autoRefresh: true,
        refreshInterval: 30000 // 30秒自动刷新
    };

    // 表情包数据
    const emojis = [
        '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
        '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
        '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
        '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
        '👍', '👎', '👌', '🤏', '✌️', '🤞', '🤟', '🤘', '🤙', '👈',
        '👉', '👆', '👇', '☝️', '👋', '🤚', '🖐️', '✋', '🖖', '👏',
        '🙌', '🤲', '🤝', '🙏', '✍️', '💪', '❤️', '🧡', '💛', '💚',
        '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓'
    ];

    // 获取当前作品ID
    function getCurrentWorkId() {
        const url = window.location.href;
        console.log('正在从URL提取作品ID:', url);
        
        // SexyAI网站使用单页应用，URL格式为 #/pages/chat/chat?roleId=xxx
        const patterns = [
            /roleId=([^&]+)/,           // roleId参数
            /characterId=([^&]+)/,      // characterId参数
            /workId=([^&]+)/,           // workId参数
            /id=([^&]+)/,               // 通用id参数
            /\/chat\/([^\/?]+)/,         // chat路径中的ID
            /\/character\/([^\/?]+)/,    // character路径中的ID
            /\/work\/([^\/?]+)/,         // work路径中的ID
            /\/story\/([^\/?]+)/,        // story路径中的ID
            /\/image\/([^\/?]+)/         // image路径中的ID
        ];
        
        for (const pattern of patterns) {
            const match = url.match(pattern);
            if (match && match[1]) {
                console.log('成功提取作品ID:', match[1]);
                return match[1];
            }
        }
        
        // 如果URL中没有明确的ID，尝试从页面元素中获取
        const titleElement = document.querySelector('h1, .title, .work-title, .character-name, .chat-title');
        if (titleElement) {
            const title = titleElement.textContent.trim();
            if (title) {
                // 使用标题的哈希值作为ID
                const hashId = btoa(encodeURIComponent(title)).replace(/[^a-zA-Z0-9]/g, '').substring(0, 16);
                console.log('使用标题生成ID:', hashId, '标题:', title);
                return hashId;
            }
        }
        
        // 最后使用URL哈希部分作为ID
        const hashPart = window.location.hash || window.location.pathname;
        const fallbackId = btoa(encodeURIComponent(hashPart)).replace(/[^a-zA-Z0-9]/g, '').substring(0, 16);
        console.log('使用URL哈希生成ID:', fallbackId, '哈希:', hashPart);
        return fallbackId;
    }

    // 获取作品信息
    function getWorkInfo() {
        const titleElement = document.querySelector('h1, .title, .work-title, .character-name, .chat-title');
        const title = titleElement ? titleElement.textContent.trim() : '未知作品';
        
        const authorElement = document.querySelector('.author, .creator, .username, .character-author');
        const author = authorElement ? authorElement.textContent.trim() : '未知作者';
        
        return { title, author };
    }

    // 创建留言板
    async function createCommentBoard() {
        const board = document.createElement('div');
        board.id = 'sexyai-shared-comment-board';
        board.className = `comment-board ${settings.position}${isMinimized ? ' minimized' : ''}`;
        
        const workInfo = getWorkInfo();
        const comments = await storage.getComments(currentWorkId);
        const stats = await storage.getWorkStats(currentWorkId);
        
        board.innerHTML = `
            <div class="comment-board-header">
                <div class="comment-board-title">
                    🌐 共享留言板
                    <span class="comment-count">${comments.length}</span>
                    <span class="online-indicator" title="${useCloudStorage ? '云端同步' : '本地存储'}">${useCloudStorage ? '☁️' : '💾'}</span>
                </div>
                <div class="comment-board-controls">
                    <button class="control-btn" id="refresh-btn" title="刷新">🔄</button>
        
                    <button class="control-btn" id="minimize-btn" title="${isMinimized ? '展开' : '收起'}">${isMinimized ? '📖' : '📕'}</button>
                    <button class="control-btn" id="close-btn" title="关闭">✖️</button>
                </div>

            </div>
            <div class="comment-board-content">
                <div class="work-info">
                    <strong>📖 ${workInfo.title}</strong><br>
                    <small>👤 ${workInfo.author}</small><br>
                    <div class="work-stats">
                        <span>👀 ${stats.views}</span>
                        <span>💬 ${stats.comments}</span>
                        <span>👍 ${stats.likes}</span>
                    </div>
                </div>
                <div class="comments-list" id="comments-list">
                    ${renderComments(comments)}
                </div>
                <div class="comment-input-area">
                    ${settings.allowAnonymous ? '' : '<input type="text" class="author-input" id="author-input" placeholder="您的昵称" maxlength="20">'}
                    <textarea class="comment-input" id="comment-input" placeholder="写下您的留言...（所有用户可见）" maxlength="500"></textarea>
                    <div class="input-controls">
                        <div class="emoji-picker">
                            ${emojis.slice(0, 10).map(emoji => `<button class="emoji-btn" data-emoji="${emoji}">${emoji}</button>`).join('')}
                        </div>
                        <button class="submit-btn" id="submit-comment">发送到云端</button>
                    </div>
                </div>
            </div>
        `;
        
        return board;
    }

    // 渲染评论列表
    function renderComments(comments) {
        if (comments.length === 0) {
            return '<div class="no-comments">暂无留言，快来抢沙发吧！<br><small>💡 所有用户都能看到您的留言</small></div>';
        }
        
        return comments.map(comment => `
            <div class="comment-item" data-id="${comment.id}" data-key="${comment.key || ''}">
                <div class="comment-header">
                    <span class="comment-author">${escapeHtml(comment.author)}</span>
                    <span class="comment-time">${formatTime(comment.timestamp)}</span>
                    <span class="comment-source" title="云端评论">☁️</span>
                </div>
                <div class="comment-content">${escapeHtml(comment.content)}</div>
                <div class="comment-actions">
                    <button class="comment-action-btn like-btn" data-id="${comment.id}" data-key="${comment.key || ''}">
                        👍 ${comment.likes || 0}
                    </button>
                    <button class="comment-action-btn reply-btn" data-id="${comment.id}">
                        💬 回复
                    </button>
                    <button class="comment-action-btn report-btn" data-id="${comment.id}">
                        🚨 举报
                    </button>
                </div>
            </div>
        `).join('');
    }

    // 时间格式化
    function formatTime(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        
        if (diff < 60000) {
            return '刚刚';
        } else if (diff < 3600000) {
            return `${Math.floor(diff / 60000)}分钟前`;
        } else if (diff < 86400000) {
            return `${Math.floor(diff / 3600000)}小时前`;
        } else {
            const date = new Date(timestamp);
            return `${date.getMonth() + 1}-${date.getDate()} ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`;
        }
    }

    // HTML转义
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // 初始化事件监听
    function initializeEvents() {
        if (!commentBoard) return;

        // 设置按钮已移除 - 用户只能使用评论功能

        // 最小化按钮
        const minimizeBtn = commentBoard.querySelector('#minimize-btn');
        minimizeBtn?.addEventListener('click', toggleMinimize);

        // 关闭按钮
        const closeBtn = commentBoard.querySelector('#close-btn');
        closeBtn?.addEventListener('click', hideCommentBoard);

        // 刷新按钮
        const refreshBtn = commentBoard.querySelector('#refresh-btn');
        refreshBtn?.addEventListener('click', refreshComments);

        // 提交评论
        const submitBtn = commentBoard.querySelector('#submit-comment');
        submitBtn?.addEventListener('click', submitComment);

        // 表情按钮
        const emojiButtons = commentBoard.querySelectorAll('.emoji-btn');
        emojiButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const emoji = e.target.dataset.emoji;
                const input = commentBoard.querySelector('#comment-input');
                if (input) {
                    input.value += emoji;
                    input.focus();
                }
            });
        });

        // 评论操作
        const commentsList = commentBoard.querySelector('#comments-list');
        commentsList?.addEventListener('click', async (e) => {
            const target = e.target;
            if (target.classList.contains('like-btn')) {
                await handleLike(target);
            } else if (target.classList.contains('reply-btn')) {
                handleReply(target);
            } else if (target.classList.contains('report-btn')) {
                handleReport(target);
            }
        });

        // 设置功能已移除 - 用户只能使用评论功能，无法修改配置
    }

    // 提交评论
    async function submitComment() {
        const input = commentBoard.querySelector('#comment-input');
        const authorInput = commentBoard.querySelector('#author-input');
        const submitBtn = commentBoard.querySelector('#submit-comment');
        
        if (!input || !input.value.trim()) {
            alert('请输入留言内容');
            return;
        }

        const content = input.value.trim();
        const author = authorInput ? authorInput.value.trim() : (settings.allowAnonymous ? '匿名用户' : '游客');

        if (!settings.allowAnonymous && !author) {
            alert('请输入您的昵称');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = '发送中...';

        try {
            const comment = {
                id: Date.now().toString(),
                content: content,
                author: author || '匿名用户',
                timestamp: Date.now(),
                likes: 0,
                ip: await getClientIP() // 用于防刷
            };

            await storage.addComment(currentWorkId, comment);
                
                // 更新统计信息
                const stats = await storage.getWorkStats(currentWorkId);
                stats.comments = (stats.comments || 0) + 1;
                await storage.updateWorkStats(currentWorkId, stats);

            input.value = '';
            if (authorInput) authorInput.value = '';
            
            await refreshComments();
            
        } catch (error) {
            console.error('提交评论失败:', error);
            alert('提交失败，请检查网络连接');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = '发送到云端';
        }
    }

    // 获取客户端IP（用于防刷）
    async function getClientIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch {
            return 'unknown';
        }
    }

    // 处理点赞
    async function handleLike(button) {
        const commentKey = button.dataset.key;
        if (!commentKey) return;

        try {
            const currentLikes = parseInt(button.textContent.match(/\d+/)[0]) || 0;
            const newLikes = currentLikes + 1;
            
            await storage.likeComment(currentWorkId, commentKey, newLikes);
            button.innerHTML = `👍 ${newLikes}`;
            
        } catch (error) {
            console.error('点赞失败:', error);
        }
    }

    // 处理回复
    function handleReply(button) {
        const commentId = button.dataset.id;
        const input = commentBoard.querySelector('#comment-input');
        if (input) {
            input.value = `@${commentId} `;
            input.focus();
        }
    }

    // 处理举报
    function handleReport(button) {
        const commentId = button.dataset.id;
        if (confirm('确定要举报这条评论吗？')) {
            // 这里可以实现举报功能
            alert('举报已提交，感谢您的反馈');
        }
    }

    // 刷新评论
    async function refreshComments() {
        if (!commentBoard) return;

        const commentsList = commentBoard.querySelector('#comments-list');
        const commentCount = commentBoard.querySelector('.comment-count');
        
        try {
            const comments = await storage.getComments(currentWorkId);
            commentsList.innerHTML = renderComments(comments);
            commentCount.textContent = comments.length;
        } catch (error) {
            console.error('刷新评论失败:', error);
        }
    }

    // 切换最小化状态
    function toggleMinimize() {
        isMinimized = !isMinimized;
        commentBoard.classList.toggle('minimized', isMinimized);
        
        const minimizeBtn = commentBoard.querySelector('#minimize-btn');
        minimizeBtn.textContent = isMinimized ? '📖' : '📕';
        minimizeBtn.title = isMinimized ? '展开' : '收起';
        
        saveSettings();
    }

    // 更新留言板位置
    function updateBoardPosition() {
        if (!commentBoard) return;
        
        commentBoard.className = `comment-board ${settings.position}${isMinimized ? ' minimized' : ''}`;
    }

    // 显示留言板
    async function showCommentBoard() {
        try {
            // 确保存储系统已初始化
            if (!storage) {
                console.log('存储系统未初始化，使用本地存储');
                storage = new LocalCommentStorage();
                useCloudStorage = false;
            }
            
            if (commentBoard) {
                commentBoard.style.display = 'block';
                return;
            }

            // 显示加载状态
            const loadingDiv = document.createElement('div');
            loadingDiv.id = 'comment-board-loading';
            loadingDiv.style.cssText = `
                position: fixed;
                top: 50%;
                right: 20px;
                transform: translateY(-50%);
                background: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 20px;
                border-radius: 8px;
                z-index: 9999;
                font-family: Arial, sans-serif;
            `;
            loadingDiv.innerHTML = '正在加载留言板...';
            document.body.appendChild(loadingDiv);

            try {
                commentBoard = await createCommentBoard();
                document.body.appendChild(commentBoard);
                initializeEvents();
                
                // 自动刷新
                if (settings.autoRefresh) {
                    setInterval(refreshComments, settings.refreshInterval);
                }
            } catch (error) {
                console.error('创建留言板失败:', error);
                
                // 创建错误提示
                const errorBoard = document.createElement('div');
                errorBoard.id = 'sexyai-shared-comment-board';
                errorBoard.className = `comment-board ${settings.position}`;
                errorBoard.innerHTML = `
                    <div class="comment-board-header">
                        <div class="comment-board-title">❌ 留言板加载失败</div>
                        <div class="comment-board-controls">
                            <button class="control-btn" id="retry-btn" title="重试">🔄</button>
                            <button class="control-btn" id="close-btn" title="关闭">✖️</button>
                        </div>
                    </div>
                    <div class="comment-board-content">
                        <div style="padding: 20px; text-align: center; color: #ff6b9d;">
                            <p>😔 无法连接到留言板服务</p>
                            <p style="font-size: 12px; color: #ccc; margin-top: 10px;">
                                可能的原因：<br>
                                • 网络连接问题<br>
                                • Firebase服务异常<br>
                                • 扩展配置错误
                            </p>
                            <button id="switch-local" style="
                                background: #4CAF50;
                                color: white;
                                border: none;
                                padding: 8px 16px;
                                border-radius: 4px;
                                cursor: pointer;
                                margin-top: 10px;
                            ">切换到本地模式</button>
                        </div>
                    </div>
                `;
                
                commentBoard = errorBoard;
                document.body.appendChild(commentBoard);
                
                // 添加重试和切换本地模式的事件
                const retryBtn = commentBoard.querySelector('#retry-btn');
                const switchLocalBtn = commentBoard.querySelector('#switch-local');
                const closeBtn = commentBoard.querySelector('#close-btn');
                
                retryBtn?.addEventListener('click', async () => {
                    commentBoard.remove();
                    commentBoard = null;
                    await showCommentBoard();
                });
                
                switchLocalBtn?.addEventListener('click', async () => {
                    // 强制切换到本地存储
                    storage = new LocalCommentStorage();
                    useCloudStorage = false;
                    commentBoard.remove();
                    commentBoard = null;
                    await showCommentBoard();
                });
                
                closeBtn?.addEventListener('click', hideCommentBoard);
            }
            
            // 移除加载提示
            if (loadingDiv && loadingDiv.parentNode) {
                loadingDiv.remove();
            }
            
        } catch (error) {
            console.error('显示留言板失败:', error);
            alert('留言板加载失败，请刷新页面后重试');
        }
    }

    // 隐藏留言板
    function hideCommentBoard() {
        if (commentBoard) {
            commentBoard.style.display = 'none';
        }
    }

    // 检查留言板是否可见
    function isCommentBoardVisible() {
        return commentBoard && commentBoard.style.display !== 'none' && document.body.contains(commentBoard);
    }

    // 设置功能已移除 - 使用固定配置确保所有用户体验一致
    function saveSettings() {
        // 不再保存设置，使用固定配置
    }

    async function loadSettings() {
        // 不再加载设置，使用固定配置
        return Promise.resolve();
    }

    // 判断是否应该显示留言板
    function shouldShowCommentBoard() {
        // 检查是否在作品页面
        const patterns = [
            /\/work\//,
            /\/chat\//,
            /\/character\//,
            /\/story\//,
            /\/image\//
        ];
        
        return patterns.some(pattern => pattern.test(window.location.pathname));
    }

    // 创建控制按钮
    function createControlButton() {
        const button = document.createElement('button');
        button.id = 'sexyai-comment-toggle';
        button.innerHTML = '💬';
        button.title = '打开共享留言板';
        button.style.cssText = `
            position: fixed;
            top: 50%;
            right: 10px;
            z-index: 9998;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(45deg, #ff6b9d, #4ecdc4);
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            transform: translateY(-50%);
        `;
        
        button.addEventListener('click', showCommentBoard);
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'translateY(-50%) scale(1.1)';
        });
        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translateY(-50%) scale(1)';
        });
        
        document.body.appendChild(button);
    }

    // 监听页面变化
    function observePageChanges() {
        const observer = new MutationObserver((mutations) => {
            const newWorkId = getCurrentWorkId();
            if (newWorkId !== currentWorkId) {
                currentWorkId = newWorkId;
                if (commentBoard) {
                    refreshComments();
                }
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // 初始化
    async function init() {
        try {
            console.log('开始初始化 SexyAI 共享留言板（只读模式）...');
            
            // 异步初始化存储系统
            try {
                storage = await initializeStorage();
                console.log('存储系统初始化成功');
            } catch (storageError) {
                console.warn('存储系统初始化失败，使用本地存储:', storageError);
                storage = new LocalCommentStorage();
                useCloudStorage = false;
            }
            
            // 检查是否在支持的页面
            if (!shouldShowCommentBoard()) {
                console.log('当前页面不支持留言板功能');
                return;
            }

            // 获取作品ID（可能为空，但不影响基本功能）
            currentWorkId = getCurrentWorkId();
            if (!currentWorkId) {
                console.warn('无法获取作品ID，但继续初始化基本功能');
            } else {
                console.log('当前作品ID:', currentWorkId);
            }

            // 创建控制按钮
            createControlButton();
            console.log('控制按钮已创建');
            
            // 如果设置为默认显示，则立即显示留言板
            if (settings.showByDefault && currentWorkId) {
                await showCommentBoard();
            }

            // 监听页面变化
            observePageChanges();
            
            console.log('SexyAI 共享留言板初始化完成');
            
        } catch (error) {
            console.error('初始化失败:', error);
            // 确保至少有本地存储可用
            if (!storage) {
                storage = new LocalCommentStorage();
                useCloudStorage = false;
                console.log('使用本地存储作为最后备用');
            }
        }
    }

    // 监听来自popup的消息
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        try {
            switch (request.action) {
                case 'toggleCommentBoard':
                    console.log('收到切换留言板请求');
                    if (isCommentBoardVisible()) {
                        console.log('隐藏留言板');
                        hideCommentBoard();
                        sendResponse({ success: true, action: 'hidden' });
                    } else {
                        console.log('显示留言板');
                        // 检查是否有作品ID
                        if (!currentWorkId) {
                            currentWorkId = getCurrentWorkId();
                            console.log('重新获取作品ID:', currentWorkId);
                        }
                        
                        if (!currentWorkId) {
                            console.warn('无法获取作品ID，显示通用留言板');
                            sendResponse({ success: false, error: '当前页面不支持留言板功能，请在作品详情页使用' });
                            return;
                        }
                        
                        showCommentBoard().then(() => {
                            console.log('留言板显示成功');
                            sendResponse({ success: true, action: 'shown' });
                        }).catch(error => {
                            console.error('显示留言板失败:', error);
                            sendResponse({ success: false, error: error.message });
                        });
                    }
                    return true; // 保持消息通道开放以支持异步响应
                    
                case 'refreshComments':
                    if (isCommentBoardVisible()) {
                        refreshComments();
                        sendResponse({ success: true });
                    } else {
                        sendResponse({ success: false, error: '留言板未显示' });
                    }
                    break;
                    
                case 'getBoardStatus':
                    sendResponse({ 
                        visible: isCommentBoardVisible(),
                        workId: currentWorkId
                    });
                    break;
                    
                default:
                    sendResponse({ success: false, error: '未知操作' });
            }
        } catch (error) {
            console.error('处理消息失败:', error);
            sendResponse({ success: false, error: error.message });
        }
    });

    // 页面加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();