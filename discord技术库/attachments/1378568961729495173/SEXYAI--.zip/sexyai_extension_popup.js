// SexyAI 共享留言板 - 弹出页面脚本
// 处理弹出页面的用户交互和设置管理

class PopupManager {
    constructor() {
        this.port = null;
        this.currentTab = null;
        this.settings = {};
        this.stats = {};
        
        this.init();
    }

    async init() {
        try {
            // 建立与后台脚本的连接
            this.port = chrome.runtime.connect({ name: 'popup' });
            this.setupPortListeners();
            
            // 获取当前标签页信息
            await this.getCurrentTab();
            
            // 加载设置和统计信息
            await this.loadSettings();
            await this.loadStats();
            
            // 初始化UI
            this.initializeUI();
            this.updateStatus();
            
            // 绑定事件监听器
            this.bindEventListeners();
            
        } catch (error) {
            console.error('初始化失败:', error);
            this.showMessage('初始化失败，请刷新页面重试', 'error');
        }
    }

    setupPortListeners() {
        this.port.onMessage.addListener((msg) => {
            switch (msg.action) {
                case 'stats':
                    this.stats = msg.data;
                    this.updateStatsDisplay();
                    break;
                case 'exportData':
                    this.downloadExportData(msg.data);
                    break;
                case 'importSuccess':
                    this.showMessage('设置导入成功！', 'success');
                    this.loadSettings();
                    break;
                case 'importError':
                    this.showMessage(`导入失败: ${msg.error}`, 'error');
                    break;
            }
        });
    }

    async getCurrentTab() {
        return new Promise((resolve) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                this.currentTab = tabs[0];
                resolve(this.currentTab);
            });
        });
    }

    async loadSettings() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'getSettings' }, (response) => {
                this.settings = response || {};
                resolve(this.settings);
            });
        });
    }

    async saveSettings() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({
                action: 'saveSettings',
                settings: this.settings
            }, (response) => {
                if (response.success) {
                    this.showMessage('设置已保存', 'success');
                }
                resolve(response);
            });
        });
    }

    loadStats() {
        this.port.postMessage({ action: 'getStats' });
    }

    initializeUI() {
        // 设置切换开关状态
        this.updateToggle('autoShow', this.settings.showByDefault);
        this.updateToggle('autoRefresh', this.settings.autoRefresh);
        
        // 设置下拉选择框
        document.getElementById('position').value = this.settings.position || 'right-side';
        document.getElementById('theme').value = this.settings.theme || 'dark';
    }

    updateToggle(id, active) {
        const toggle = document.getElementById(id);
        if (toggle) {
            toggle.classList.toggle('active', active);
        }
    }

    updateStatus() {
        const isSexyAI = this.currentTab && /https?:\/\/(www\.)?sexyai\.top/.test(this.currentTab.url);
        
        // 更新连接状态
        const connectionStatus = document.getElementById('connectionStatus');
        connectionStatus.textContent = '已连接';
        connectionStatus.className = 'status-value';
        
        // 更新当前页面
        const currentPage = document.getElementById('currentPage');
        if (isSexyAI) {
            currentPage.textContent = 'SexyAI';
            currentPage.className = 'status-value';
        } else {
            currentPage.textContent = '其他网站';
            currentPage.className = 'status-value inactive';
        }
        
        // 更新留言板状态
        const statusElement = document.getElementById('boardStatus');
        if (isSexyAI) {
            // 检查留言板状态
            this.checkBoardStatus();
        } else {
            statusElement.textContent = '未连接';
            statusElement.className = 'status-value inactive';
        }
    }

    checkBoardStatus() {
        const isSexyAI = this.currentTab && /https?:\/\/(www\.)?sexyai\.top/.test(this.currentTab.url);
        const boardStatus = document.getElementById('boardStatus');
        
        if (isSexyAI) {
            // 向内容脚本查询留言板状态
            chrome.tabs.sendMessage(this.currentTab.id, { action: 'getBoardStatus' }, (response) => {
                if (chrome.runtime.lastError) {
                    boardStatus.textContent = '未加载';
                    boardStatus.className = 'status-value inactive';
                } else if (response && response.visible) {
                    boardStatus.textContent = '已显示';
                    boardStatus.className = 'status-value';
                } else {
                    boardStatus.textContent = '已连接';
                    boardStatus.className = 'status-value';
                }
            });
        } else {
            boardStatus.textContent = '不适用';
            boardStatus.className = 'status-value inactive';
        }
    }

    updateStatsDisplay() {
        document.getElementById('commentsCount').textContent = this.stats.commentsPosted || 0;
        document.getElementById('sitesVisited').textContent = this.stats.sitesVisited || 0;
    }

    bindEventListeners() {
        // 切换开关事件
        document.getElementById('autoShow').addEventListener('click', () => {
            this.settings.showByDefault = !this.settings.showByDefault;
            this.updateToggle('autoShow', this.settings.showByDefault);
            this.saveSettings();
        });

        document.getElementById('autoRefresh').addEventListener('click', () => {
            this.settings.autoRefresh = !this.settings.autoRefresh;
            this.updateToggle('autoRefresh', this.settings.autoRefresh);
            this.saveSettings();
        });

        // 下拉选择框事件
        document.getElementById('position').addEventListener('change', (e) => {
            this.settings.position = e.target.value;
            this.saveSettings();
        });

        document.getElementById('theme').addEventListener('change', (e) => {
            this.settings.theme = e.target.value;
            this.saveSettings();
        });

        // 快速操作按钮
        document.getElementById('toggleBoard').addEventListener('click', () => {
            this.toggleCommentBoard();
        });

        document.getElementById('refreshComments').addEventListener('click', () => {
            this.refreshComments();
        });

        document.getElementById('clearCache').addEventListener('click', () => {
            this.clearCache();
        });

        document.getElementById('exportData').addEventListener('click', () => {
            this.exportSettings();
        });

        // 底部按钮
        document.getElementById('openOptions').addEventListener('click', () => {
            chrome.runtime.openOptionsPage();
            window.close();
        });

        document.getElementById('openHelp').addEventListener('click', () => {
            chrome.tabs.create({ url: 'https://github.com/your-repo/sexyai-comment-board/wiki' });
            window.close();
        });
    }

    toggleCommentBoard() {
        const isSexyAI = this.currentTab && /https?:\/\/(www\.)?sexyai\.top/.test(this.currentTab.url);
        
        if (!isSexyAI) {
            this.showMessage('请在 SexyAI 网站上使用此功能', 'error');
            return;
        }

        // 显示加载状态
        this.showMessage('正在切换留言板状态...', 'info');

        chrome.tabs.sendMessage(this.currentTab.id, { action: 'toggleCommentBoard' }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('通信错误:', chrome.runtime.lastError);
                this.showMessage('无法连接到页面，请刷新页面后重试', 'error');
            } else if (response && response.success) {
                const action = response.action === 'shown' ? '已显示' : '已隐藏';
                this.showMessage(`留言板${action}`, 'success');
                setTimeout(() => this.checkBoardStatus(), 500);
            } else {
                const errorMsg = response && response.error ? response.error : '操作失败';
                this.showMessage(`切换失败: ${errorMsg}`, 'error');
            }
        });
    }

    refreshComments() {
        const isSexyAI = this.currentTab && /https?:\/\/(www\.)?sexyai\.top/.test(this.currentTab.url);
        
        if (!isSexyAI) {
            this.showMessage('请在 SexyAI 网站上使用此功能', 'error');
            return;
        }

        chrome.tabs.sendMessage(this.currentTab.id, { action: 'refreshComments' }, (response) => {
            if (chrome.runtime.lastError) {
                this.showMessage('无法连接到页面', 'error');
            } else {
                this.showMessage('评论已刷新', 'success');
            }
        });
    }

    clearCache() {
        chrome.storage.local.clear(() => {
            this.showMessage('缓存已清理', 'success');
            this.loadStats();
        });
    }

    exportSettings() {
        this.port.postMessage({ action: 'exportSettings' });
    }

    downloadExportData(data) {
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `sexyai-comment-board-settings-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showMessage('设置已导出', 'success');
    }

    showMessage(text, type = 'info') {
        const messageArea = document.getElementById('messageArea');
        const messageDiv = document.createElement('div');
        messageDiv.className = type;
        messageDiv.textContent = text;
        
        messageArea.innerHTML = '';
        messageArea.appendChild(messageDiv);
        
        // 3秒后自动清除消息
        setTimeout(() => {
            if (messageArea.contains(messageDiv)) {
                messageArea.removeChild(messageDiv);
            }
        }, 3000);
    }

    // 处理文件导入
    handleFileImport(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importData = JSON.parse(e.target.result);
                this.port.postMessage({ action: 'importSettings', data: importData });
            } catch (error) {
                this.showMessage('文件格式错误', 'error');
            }
        };
        reader.readAsText(file);
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    new PopupManager();
});

// 添加拖拽导入功能
document.addEventListener('dragover', (e) => {
    e.preventDefault();
});

document.addEventListener('drop', (e) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type === 'application/json') {
        const popup = window.popupManager;
        if (popup) {
            popup.handleFileImport(files[0]);
        }
    }
});

// 键盘快捷键
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
            case 'r':
                e.preventDefault();
                document.getElementById('refreshComments').click();
                break;
            case 't':
                e.preventDefault();
                document.getElementById('toggleBoard').click();
                break;
            case 'e':
                e.preventDefault();
                document.getElementById('exportData').click();
                break;
        }
    }
});

// 全局错误处理
window.addEventListener('error', (e) => {
    console.error('弹出页面错误:', e.error);
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('未处理的Promise拒绝:', e.reason);
});