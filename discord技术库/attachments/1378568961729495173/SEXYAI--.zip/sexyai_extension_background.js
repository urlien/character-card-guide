// SexyAI 共享留言板 - 后台脚本
// 处理扩展生命周期、设置管理和消息传递

// 扩展安装时的初始化
chrome.runtime.onInstalled.addListener((details) => {
    console.log('SexyAI 共享留言板扩展已安装');
    
    // 设置默认配置
    const defaultSettings = {
        position: 'right-side',
        theme: 'dark',
        showByDefault: false,
        allowAnonymous: true,
        autoRefresh: true,
        refreshInterval: 30000,
        enableNotifications: true,
        maxCommentsDisplay: 50
    };
    
    // 保存默认设置
    chrome.storage.sync.set({ sexyaiCommentSettings: defaultSettings });
    
    // 如果是首次安装，显示欢迎页面
    if (details.reason === 'install') {
        // 暂时注释掉欢迎页面，避免文件不存在的错误
        // chrome.tabs.create({
        //     url: chrome.runtime.getURL('welcome.html')
        // });
    }
    
    // 创建右键菜单项
    chrome.contextMenus.create({
        id: 'sexyai-comment-board',
        title: '打开 SexyAI 留言板',
        contexts: ['page'],
        documentUrlPatterns: ['https://www.sexyai.top/*', 'https://sexyai.top/*']
    });
    
    chrome.contextMenus.create({
        id: 'sexyai-settings',
        title: '留言板设置',
        contexts: ['page']
    });
});

// 处理来自内容脚本的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.action) {
        case 'getSettings':
            chrome.storage.sync.get(['sexyaiCommentSettings'], (result) => {
                sendResponse(result.sexyaiCommentSettings || {});
            });
            return true; // 保持消息通道开放
            
        case 'saveSettings':
            chrome.storage.sync.set({ sexyaiCommentSettings: request.settings }, () => {
                sendResponse({ success: true });
            });
            return true;
            
        case 'showNotification':
            if (request.settings?.enableNotifications) {
                chrome.notifications.create({
                    type: 'basic',
                    iconUrl: 'icons/icon48.png',
                    title: 'SexyAI 留言板',
                    message: request.message
                });
            }
            sendResponse({ success: true });
            break;
            
        case 'getBadgeCount':
            chrome.action.getBadgeText({ tabId: sender.tab.id }, (text) => {
                sendResponse({ count: parseInt(text) || 0 });
            });
            return true;
            
        case 'setBadgeCount':
            chrome.action.setBadgeText({
                tabId: sender.tab.id,
                text: request.count > 0 ? request.count.toString() : ''
            });
            chrome.action.setBadgeBackgroundColor({
                color: '#ff6b9d'
            });
            sendResponse({ success: true });
            break;
            
        default:
            sendResponse({ error: 'Unknown action' });
    }
});

// 监听标签页更新
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // 当页面加载完成时，检查是否是 SexyAI 网站
    if (changeInfo.status === 'complete' && tab.url) {
        const isSexyAI = /https?:\/\/(www\.)?sexyai\.top/.test(tab.url);
        
        if (isSexyAI) {
            // 为 SexyAI 网站设置特殊的图标
            chrome.action.setIcon({
                tabId: tabId,
                path: {
                    '16': 'icons/icon16.png',
                    '48': 'icons/icon48.png',
                    '128': 'icons/icon128.png'
                }
            });
            
            // 设置工具提示
            chrome.action.setTitle({
                tabId: tabId,
                title: 'SexyAI 共享留言板 - 点击打开设置'
            });
        }
    }
});

// 处理扩展图标点击
// 注释掉，因为manifest.json中已定义default_popup
// chrome.action.onClicked.addListener((tab) => {
//     // 检查是否在 SexyAI 网站
//     const isSexyAI = /https?:\/\/(www\.)?sexyai\.top/.test(tab.url);
//     
//     if (isSexyAI) {
//         // 在 SexyAI 网站上，向内容脚本发送消息来切换留言板
//         chrome.tabs.sendMessage(tab.id, { action: 'toggleCommentBoard' });
//     } else {
//         // 在其他网站上，打开设置页面
//         chrome.runtime.openOptionsPage();
//     }
// });

// 右键菜单已在上面的onInstalled监听器中创建

// 处理右键菜单点击
chrome.contextMenus.onClicked.addListener((info, tab) => {
    switch (info.menuItemId) {
        case 'sexyai-comment-board':
            chrome.tabs.sendMessage(tab.id, { action: 'showCommentBoard' });
            break;
        case 'sexyai-settings':
            chrome.runtime.openOptionsPage();
            break;
    }
});

// 监听存储变化
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.sexyaiCommentSettings) {
        // 设置发生变化时，通知所有相关标签页
        chrome.tabs.query({ url: ['https://www.sexyai.top/*', 'https://sexyai.top/*'] }, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    action: 'settingsChanged',
                    settings: changes.sexyaiCommentSettings.newValue
                }).catch(() => {
                    // 忽略无法发送消息的标签页
                });
            });
        });
    }
});

// 定期清理过期数据
chrome.alarms.create('cleanupExpiredData', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cleanupExpiredData') {
        cleanupExpiredData();
    }
});

// 清理过期数据函数
function cleanupExpiredData() {
    chrome.storage.local.get(null, (items) => {
        const now = Date.now();
        const expiredKeys = [];
        
        Object.keys(items).forEach(key => {
            if (key.startsWith('temp_') && items[key].expires && items[key].expires < now) {
                expiredKeys.push(key);
            }
        });
        
        if (expiredKeys.length > 0) {
            chrome.storage.local.remove(expiredKeys);
            console.log(`清理了 ${expiredKeys.length} 个过期数据项`);
        }
    });
}

// 处理网络请求拦截（可选功能）
// 暂时注释掉，避免权限问题
// chrome.webRequest.onBeforeRequest.addListener(
//     (details) => {
//         // 可以在这里添加请求拦截逻辑
//         // 例如：缓存、代理、统计等
//         return { cancel: false };
//     },
//     {
//         urls: ['https://www.sexyai.top/*', 'https://sexyai.top/*']
//     },
//     ['requestBody']
// );

// 扩展卸载时的清理
chrome.runtime.onSuspend.addListener(() => {
    console.log('SexyAI 共享留言板扩展正在卸载');
    // 执行清理操作
    cleanupExpiredData();
});

// 错误处理
chrome.runtime.onStartup.addListener(() => {
    console.log('SexyAI 共享留言板扩展已启动');
});

// 处理扩展更新
chrome.runtime.onUpdateAvailable.addListener((details) => {
    console.log('发现新版本:', details.version);
    // 可以选择立即重载或等待下次启动
    // chrome.runtime.reload();
});

// 导出配置（用于备份）
function exportSettings() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['sexyaiCommentSettings'], (result) => {
            const exportData = {
                version: chrome.runtime.getManifest().version,
                timestamp: Date.now(),
                settings: result.sexyaiCommentSettings || {}
            };
            resolve(exportData);
        });
    });
}

// 导入配置（用于恢复）
function importSettings(importData) {
    return new Promise((resolve, reject) => {
        try {
            if (importData.settings) {
                chrome.storage.sync.set({ sexyaiCommentSettings: importData.settings }, () => {
                    resolve(true);
                });
            } else {
                reject(new Error('无效的导入数据'));
            }
        } catch (error) {
            reject(error);
        }
    });
}

// 获取扩展统计信息
function getExtensionStats() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['extensionStats'], (result) => {
            const stats = result.extensionStats || {
                installDate: Date.now(),
                commentsPosted: 0,
                sitesVisited: 0,
                lastUsed: Date.now()
            };
            resolve(stats);
        });
    });
}

// 更新扩展统计信息
function updateExtensionStats(updates) {
    chrome.storage.local.get(['extensionStats'], (result) => {
        const stats = result.extensionStats || {
            installDate: Date.now(),
            commentsPosted: 0,
            sitesVisited: 0,
            lastUsed: Date.now()
        };
        
        Object.assign(stats, updates, { lastUsed: Date.now() });
        chrome.storage.local.set({ extensionStats: stats });
    });
}

// 监听来自popup的消息
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'popup') {
        port.onMessage.addListener((msg) => {
            switch (msg.action) {
                case 'getStats':
                    getExtensionStats().then(stats => {
                        port.postMessage({ action: 'stats', data: stats });
                    });
                    break;
                case 'exportSettings':
                    exportSettings().then(data => {
                        port.postMessage({ action: 'exportData', data: data });
                    });
                    break;
                case 'importSettings':
                    importSettings(msg.data).then(() => {
                        port.postMessage({ action: 'importSuccess' });
                    }).catch(error => {
                        port.postMessage({ action: 'importError', error: error.message });
                    });
                    break;
            }
        });
    }
});